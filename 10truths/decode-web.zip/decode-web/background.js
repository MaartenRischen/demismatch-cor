// Service worker — handles side panel, content script injection, single-decode API calls

// --- API config ---
const OPENROUTER_KEY = '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';
const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';

// Single decode mode: Cor architecture (cor-decode.txt)

// =============================================================================
// ARTICLE FETCHING — 3-tier robust extraction
// =============================================================================
//
// Goal: when the user decodes a section that links to an article, fetch the
// article body so the LLM has the full context, not just the homepage teaser.
//
// Tier 1: offscreen-document fetch + DOMParser extraction (no visible tab,
//   handles SSR'd HTML — covers majority of news sites).
// Tier 2: hidden background tab via chrome.tabs.create({active:false}), wait
//   for JS hydration, run the same extractor against the rendered DOM, close
//   the tab. Catches JS-rendered content the offscreen fetch misses.
// Tier 3: archive.ph fallback through Tier 1 — handles paywalls.
//
// All three feed a session cache keyed by URL.

const fetchSettings = {
  enabled: true,           // master toggle
  timeoutMs: 8000,         // per-tier timeout
  archiveFallback: true,   // try archive.ph if paywall / thin
  hydrationDelayMs: 1500,  // post-load wait for JS hydration in tab fallback
  minWordCount: 100        // below this, treat as a thin extraction and try next tier
};

// Promise to ensure offscreen document is created at most once.
let offscreenReady = null;

async function ensureOffscreen() {
  if (offscreenReady) return offscreenReady;
  offscreenReady = (async () => {
    if (chrome.offscreen && chrome.offscreen.hasDocument) {
      const exists = await chrome.offscreen.hasDocument();
      if (exists) return;
    }
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['DOM_PARSER'],
      justification: 'Parse fetched article HTML for decoder context.'
    });
  })();
  return offscreenReady;
}

// Fetch HTML in the service worker (which gets CORS exemption via
// host_permissions), then hand the raw HTML to the offscreen document for
// DOMParser-based extraction. The split is necessary because:
//   - service workers in MV3 lack DOMParser
//   - offscreen documents don't get the CORS exemption host_permissions provides
async function fetchViaOffscreen(url) {
  let html;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), fetchSettings.timeoutMs);
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });
    clearTimeout(timer);
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}`, status: res.status };
    const ct = res.headers.get('content-type') || '';
    if (!ct.includes('html')) return { ok: false, error: `non-html: ${ct}` };
    html = await res.text();
  } catch (e) {
    return { ok: false, error: e?.message || String(e) };
  }

  await ensureOffscreen();
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: 'lens_offscreen_parse', html, url },
      (resp) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          resolve(resp || { ok: false, error: 'no response from offscreen' });
        }
      }
    );
  });
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (done) return; done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('tab load timeout'));
    }, timeoutMs);
    function listener(updatedTabId, changeInfo) {
      if (updatedTabId !== tabId) return;
      if (changeInfo.status === 'complete') {
        if (done) return; done = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function fetchViaTab(url) {
  let tabId = null;
  try {
    const tab = await chrome.tabs.create({ url, active: false, pinned: false });
    tabId = tab.id;
    await waitForTabComplete(tabId, fetchSettings.timeoutMs);
    // Give JS-rendered content a moment to populate.
    await new Promise(r => setTimeout(r, fetchSettings.hydrationDelayMs));
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      files: ['lib/extractor.js']
    });
    const data = results?.[0]?.result;
    if (!data) return { ok: false, error: 'extractor returned nothing' };
    return { ok: true, ...data };
  } catch (e) {
    return { ok: false, error: e?.message || String(e) };
  } finally {
    if (tabId != null) {
      try { await chrome.tabs.remove(tabId); } catch {}
    }
  }
}

async function fetchViaArchive(url) {
  // archive.ph's "/newest/" endpoint redirects to the most recent snapshot.
  const archiveUrl = `https://archive.ph/newest/${encodeURIComponent(url)}`;
  // Archive pages are heavy JS; tab-based extraction is more reliable here.
  return await fetchViaTab(archiveUrl);
}

const ARTICLE_CACHE_KEY_PREFIX = 'lens_art_';
const ARTICLE_CACHE_TTL_MS = 60 * 60 * 1000; // 1 hour

async function readCache(url) {
  try {
    const key = ARTICLE_CACHE_KEY_PREFIX + url;
    const obj = await chrome.storage.session.get(key);
    const entry = obj?.[key];
    if (!entry) return null;
    if (Date.now() - entry.ts > ARTICLE_CACHE_TTL_MS) return null;
    return entry;
  } catch {
    return null;
  }
}

async function writeCache(url, payload) {
  try {
    const key = ARTICLE_CACHE_KEY_PREFIX + url;
    await chrome.storage.session.set({ [key]: { ...payload, ts: Date.now() } });
  } catch {}
}

async function clearArticleCache() {
  try {
    const all = await chrome.storage.session.get(null);
    const keysToRemove = Object.keys(all).filter(k => k.startsWith(ARTICLE_CACHE_KEY_PREFIX));
    if (keysToRemove.length) await chrome.storage.session.remove(keysToRemove);
    return keysToRemove.length;
  } catch {
    return 0;
  }
}

// Main entry: returns {ok, source, title, byline, body, wordCount, isPaywall, error?}
async function fetchArticleText(url) {
  if (!fetchSettings.enabled) return { ok: false, source: 'disabled' };
  if (!url) return { ok: false, source: 'no-url' };

  // Cache hit
  const cached = await readCache(url);
  if (cached && cached.body && cached.wordCount >= fetchSettings.minWordCount) {
    return { ok: true, source: 'cache', ...cached };
  }

  // Tier 1: offscreen
  let result = await fetchViaOffscreen(url);
  if (result.ok && !result.isPaywall && result.wordCount >= fetchSettings.minWordCount) {
    await writeCache(url, result);
    return { ok: true, source: 'offscreen', ...result };
  }
  const tier1Paywall = result.isPaywall;

  // Tier 2: hidden tab (catches JS-rendered)
  let tabResult = await fetchViaTab(url);
  if (tabResult.ok && !tabResult.isPaywall && tabResult.wordCount >= fetchSettings.minWordCount) {
    await writeCache(url, tabResult);
    return { ok: true, source: 'tab', ...tabResult };
  }
  const tier2Paywall = tabResult.isPaywall;

  // Tier 3: archive.ph (paywall fallback)
  if (fetchSettings.archiveFallback && (tier1Paywall || tier2Paywall)) {
    const archiveResult = await fetchViaArchive(url);
    if (archiveResult.ok && archiveResult.wordCount >= fetchSettings.minWordCount) {
      await writeCache(url, archiveResult);
      return { ok: true, source: 'archive', ...archiveResult };
    }
  }

  // Return whatever we got — even thin or paywalled is sometimes useful
  const best = (tabResult.body && tabResult.wordCount > (result.wordCount || 0)) ? tabResult : result;
  if (best.body) {
    await writeCache(url, best);
    return { ok: true, source: 'thin', ...best };
  }
  return { ok: false, source: 'none', error: best.error || 'extraction failed' };
}

// Dev decode parameters — updated live via set_decode_params from the sidepanel.
// Defaults here must mirror DP_DEFAULTS in sidepanel.js. Hardcoded baseline:
// opus-4-6, temp 1.0, max tokens 2624, max humor, deadpan+humor, very casual,
// ice cold, confrontational, no metaphor. Sidepanel pushes the same values on
// load; these are the safety net for the very first decode.
let decodeParams = {
  model: 'anthropic/claude-opus-4-6',
  temperature: 1.0,
  topP: 1.0,
  frequencyPenalty: 0.0,
  presencePenalty: 0.0,
  maxTokens: 2624,
  seed: null,
  humor: 4,              // 0 off · 1 light · 2 moderate · 3 heavy · 4 max
  tone: 1,               // 0 clinical · 1 deadpan+humor · 2 compassionate · 3 punchy · 4 academic
  formality: 1,          // 0 default · 1 very casual · 2 casual · 3 formal · 4 very formal
  warmth: 1,             // 0 default · 1 ice cold · 2 cool · 3 warm · 4 intimate
  direct: 4,             // 0 default · 1 circumspect · 2 measured · 3 blunt · 4 confrontational
  sentenceLen: 0,        // 0 default · 1 staccato · 2 short · 3 standard · 4 flowing
  metaphor: 1,           // 0 default · 1 none · 2 light · 3 rich · 4 dense
  patternForm: 0,        // 0 auto · 1 relationship · 2 inability · 3 field-note
  patternMaxWords: 6,
  patternCase: 0,        // 0 auto · 1 FORCE UPPER · 2 force sentence
  labelWords: 60,
  absolutionOn: true,
  absolutionWords: 40,
  verbosity: 1,          // 0 terse · 1 standard · 2 verbose
  multiLayer: true,
  cascadeDepth: 1,       // 0 none · 1 primary only · 2 primary + one · 3 full
  dc2Emphasis: 1,        // 0 suppress · 1 default · 2 emphasize · 3 hammer
  scaleEmphasis: 1,
  schadenfreude: 1,      // 0 suppress · 1 auto · 2 emphasize
  eeaStrictness: 1,      // 0 loose · 1 default · 2 strict · 3 max
  custom: ''
};

const _HUMOR = [
  'HUMOR: OFF. Drop the dark-humor register entirely. Pure clinical voice.',
  'HUMOR: LIGHT. One dry beat per decode at most, only where it genuinely lands.',
  'HUMOR: MODERATE. Use the TONE-section dark-humor register as written.',
  'HUMOR: HEAVY. Grumpy-robot register turned up — multiple dry beats per decode, as long as SENSITIVITY is respected.',
  'HUMOR: MAX. Grumpy-robot register pushed to the limit — dry observational beats throughout. SENSITIVITY still overrides on victim content.'
];
const _TONE = [
  'TONE: Clinical. Pure deadpan-diagnostic. No humor, no dry asides.',
  'TONE: Deadpan + dark humor, as main prompt describes.',
  'TONE: Compassionate. Emphasize the absolution beat. Warm without being soft.',
  'TONE: Punchy. Short aggressive sentences. Throat-grab cadence.',
  'TONE: Academic. Formal analytical register. Distance, precision, no flourishes.'
];
const _FORMALITY = [null,
  'FORMALITY: Very casual. Contractions, informal idioms, "you\'re," "it\'s."',
  'FORMALITY: Casual. Contractions allowed, informal cadence.',
  'FORMALITY: Formal. Minimal contractions, measured register.',
  'FORMALITY: Very formal. No contractions. Full-form verb usage. No idioms.'
];
const _WARMTH = [null,
  'WARMTH: Ice cold. Strip every warm modifier. Diagnostic, distant.',
  'WARMTH: Cool. Measured. No warmth in the absolution beat.',
  'WARMTH: Warm. Let the absolution beat carry explicit compassion.',
  'WARMTH: Intimate. Address the reader as if in a close, quiet conversation.'
];
const _DIRECT = [null,
  'DIRECTNESS: Circumspect. Hedge where honest. Allow "might," "often."',
  'DIRECTNESS: Measured. Direct claims only where well supported.',
  'DIRECTNESS: Blunt. State it flat. No hedging.',
  'DIRECTNESS: Confrontational. Name what the reader is doing without softening.'
];
const _SENTL = [null,
  'SENTENCE LENGTH: Staccato. Five-word sentences. Rhythm through rupture.',
  'SENTENCE LENGTH: Short. 8–12 words per sentence target.',
  'SENTENCE LENGTH: Standard. Mix short and medium sentences.',
  'SENTENCE LENGTH: Flowing. Allow longer sentences (up to 25 words) where they carry rhythm.'
];
const _META = [null,
  'METAPHOR: None. Literal language only. No figurative devices.',
  'METAPHOR: Light. Metaphor where it genuinely earns its place, sparingly.',
  'METAPHOR: Rich. Reach for image-forward phrasing where the mechanism allows.',
  'METAPHOR: Dense. Metaphor-forward voice — still deadpan, still true.'
];
const _PFORM = [
  'PATTERN FORM: Auto. Pick whichever plain-fact shape cuts hardest per content.',
  'PATTERN FORM: Force RELATIONSHIP FACT — state plainly that the reader is not in the scene (e.g. "SHE HAS NEVER HEARD OF YOU."). Reader-position asymmetry as the cut.',
  'PATTERN FORM: Force INABILITY FACT — state plainly what the reader cannot do about this story (e.g. "IT ISN\'T YOUR FIGHT."). The alarm firing with no available action as the cut.',
  'PATTERN FORM: Force ARCHITECTURAL FIELD NOTE — compress ancient system + modern input into one flat chart-note sentence (e.g. "YOUR THREAT SYSTEM IS READING A COURT FILING.").'
];
const _PCASE = [null,
  'PATTERN NAME CASE: Force ALL CAPS output regardless of form.',
  'PATTERN NAME CASE: Force sentence case output (first letter cap only).'
];
const _VERB = [
  'VERBOSITY: Terse. Label max 40 words. Absolution max 25. Breakdown sections max 30 each.',
  'VERBOSITY: Standard. Lengths as in main prompt.',
  'VERBOSITY: Verbose. Up to 2× standard lengths. Do not become convoluted — still short sentences.'
];
const _CASC = [
  'CASCADE: Suppress. Do not mention cascading suppression of other mechanisms.',
  'CASCADE: Primary only. Name the primary mechanism\'s direct suppression targets.',
  'CASCADE: Primary + one. Name primary cascade plus one second-order effect.',
  'CASCADE: Full. Walk the full cascade chain where relevant.'
];
const _DC2 = [
  'DC2 EMPHASIS: Suppress. Do not mention industry / market proxy exploitation.',
  'DC2 EMPHASIS: Default. Mention DC2 when it clearly applies.',
  'DC2 EMPHASIS: Emphasize. Name the business model explicitly whenever DC2 applies.',
  'DC2 EMPHASIS: Hammer. DC2 is a recurring throughline in the decode — always name it.'
];
const _SCALE = [
  'SCALE RULE: Suppress. Do not invoke scale-detachment as the failure.',
  'SCALE RULE: Default. Apply when the system is above Dunbar.',
  'SCALE RULE: Emphasize. Explicitly state scale as the failure whenever above Dunbar.',
  'SCALE RULE: Hammer. Name scale-as-failure even when only weakly applicable.'
];
const _SCHD = [
  'SCHADENFREUDE: Suppress. Do not invoke the rival-fall submodule even on relevant content.',
  'SCHADENFREUDE: Auto. Invoke when the content depicts a rival / opponent / power figure falling.',
  'SCHADENFREUDE: Emphasize. When any political / celebrity / power fall is depicted, explicitly name the schadenfreude submodule firing.'
];
const _EEA = [
  'EEA STRICTNESS: Loose. Modern-neutral vocabulary OK where natural.',
  'EEA STRICTNESS: Default. Apply EEA-native vocabulary as described in main prompt.',
  'EEA STRICTNESS: Strict. All nouns must be EEA-native or plain-English mechanism outputs.',
  'EEA STRICTNESS: Max. Purge every modern-institutional noun. Every word from the organism\'s vocabulary.'
];

function buildDevOverrides(p) {
  const lines = ['', '--- DEV OVERRIDES (this generation only, take precedence over main prompt) ---'];

  // Voice
  lines.push(_HUMOR[p.humor]);
  lines.push(_TONE[p.tone]);
  if (p.formality)   lines.push(_FORMALITY[p.formality]);
  if (p.warmth)      lines.push(_WARMTH[p.warmth]);
  if (p.direct)      lines.push(_DIRECT[p.direct]);
  if (p.sentenceLen) lines.push(_SENTL[p.sentenceLen]);
  if (p.metaphor)    lines.push(_META[p.metaphor]);

  // Structure
  if (p.patternForm) lines.push(_PFORM[p.patternForm]);
  if (p.patternMaxWords && p.patternMaxWords !== 6) {
    lines.push(`PATTERN NAME: Maximum ${p.patternMaxWords} words.`);
  }
  if (p.patternCase) lines.push(_PCASE[p.patternCase]);
  if (p.labelWords && p.labelWords !== 60) {
    lines.push(`LABEL LENGTH: Target ${p.labelWords} words.`);
  }
  if (!p.absolutionOn) {
    lines.push('ABSOLUTION: OFF. Omit the absolution field entirely — return an empty string or skip it.');
  } else if (p.absolutionWords && p.absolutionWords !== 40) {
    lines.push(`ABSOLUTION LENGTH: Target ${p.absolutionWords} words.`);
  }
  lines.push(_VERB[p.verbosity]);

  // Framework emphasis
  if (!p.multiLayer) {
    lines.push('MULTI-LAYER: OFF. Decode only the reader\'s mismatch. Skip performer/industry layers.');
  } else {
    lines.push('MULTI-LAYER: ON. Apply MULTI-ACTOR RULE — name all actor layers of mismatch.');
  }
  lines.push(_CASC[p.cascadeDepth]);
  lines.push(_DC2[p.dc2Emphasis]);
  lines.push(_SCALE[p.scaleEmphasis]);
  lines.push(_SCHD[p.schadenfreude]);
  lines.push(_EEA[p.eeaStrictness]);

  // Custom tail
  if (p.custom && p.custom.trim()) {
    lines.push('', 'CUSTOM INSTRUCTIONS (highest priority, override anything above that conflicts):');
    lines.push(p.custom.trim());
  }

  lines.push('---');
  return lines.join('\n');
}

// Enable side panel on action click, scoped to the clicked tab
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.setOptions({
    tabId: tab.id,
    path: 'sidepanel.html',
    enabled: true
  });
  chrome.sidePanel.open({ tabId: tab.id });
});

// Message router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Sidepanel pushes dev decode parameters (temperature, humor, tone, etc.)
  if (message.type === 'set_decode_params') {
    decodeParams = { ...decodeParams, ...(message.params || {}) };
    sendResponse({ ok: true });
    return false;
  }

  // Sidepanel pushes article-fetch settings (enabled, timeout, archive, etc.)
  if (message.type === 'set_fetch_settings') {
    Object.assign(fetchSettings, message.settings || {});
    sendResponse({ ok: true });
    return false;
  }

  // Sidepanel asks for a session-cache wipe.
  if (message.type === 'clear_article_cache') {
    clearArticleCache().then(n => sendResponse({ ok: true, removed: n }));
    return true;
  }

  // Sidebar requests content script injection + selection mode
  if (message.type === 'inject_and_enable') {
    handleInjectAndEnable(message.tabId).then(sendResponse);
    return true;
  }

  // Content script reports a section click — decode it
  if (message.type === 'section_clicked') {
    const tabId = sender.tab?.id;
    if (tabId) {
      handleSectionClicked(tabId, message);
    }
    sendResponse({ received: true });
    return false;
  }

  // Content script asks the extension to pop the side panel open (e.g. user
  // clicked a floating card's body or the exhibit tag on the page). Best-effort
  // — if no user gesture is in scope, the call silently fails and the message
  // flow falls back to whatever listener is already live in the side panel.
  if (message.type === 'request_open_sidepanel') {
    const tabId = sender.tab?.id;
    const windowId = sender.tab?.windowId;
    if (tabId && chrome.sidePanel?.open) {
      chrome.sidePanel.open({ tabId }).catch(() => {
        if (windowId) chrome.sidePanel.open({ windowId }).catch(() => {});
      });
    }
    sendResponse({ received: true });
    return false;
  }

  // Forward commands from sidebar to content script
  if (message.type === 'scroll_to_decode' || message.type === 'toggle_overlays' || message.type === 'remove_all_decodes') {
    const tabId = message.tabId;
    if (tabId) {
      chrome.tabs.sendMessage(tabId, message).then(sendResponse).catch(() => sendResponse(null));
    }
    return true;
  }
});

// --- Inject content script and enable selection mode ---

async function handleInjectAndEnable(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
  } catch (e) {
    return { error: `Injection failed: ${e.message}` };
  }

  await new Promise(r => setTimeout(r, 200));

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const result = await chrome.tabs.sendMessage(tabId, { type: 'enable_selection' });
      return result;
    } catch (e) {
      if (attempt < 2) {
        await new Promise(r => setTimeout(r, 500));
      } else {
        return { error: `Enable failed after 3 attempts: ${e.message}` };
      }
    }
  }
}

// --- Single-section decode via OpenRouter ---

async function handleSectionClicked(tabId, message) {
  const { decodeId, exhibitNum, headlines, text, articleUrl } = message;

  try {
    const basePrompt = await fetch(chrome.runtime.getURL('prompts/cor-decode.txt')).then(r => r.text());
    const systemPrompt = basePrompt + buildDevOverrides(decodeParams);

    const headlinesList = headlines.map(h => `- ${h}`).join('\n');
    let userMessage = `SECTION HEADLINES:\n${headlinesList}\n\nSECTION TEXT:\n${text}`;

    // Article fetch (if enabled and a URL is available). Wrapped in try/catch
    // so a fetch failure NEVER breaks the decode — we just decode what we have.
    let articleResult = null;
    if (fetchSettings.enabled && articleUrl) {
      try {
        // Tell the floating card we're fetching, so the user has feedback.
        chrome.tabs.sendMessage(tabId, {
          type: 'decode_status',
          decodeId,
          status: 'Reading article…'
        }).catch(() => {});
        articleResult = await fetchArticleText(articleUrl);
      } catch (e) {
        articleResult = { ok: false, source: 'error', error: e?.message || String(e) };
      }
      // Tell the card we're handing off to the model.
      chrome.tabs.sendMessage(tabId, {
        type: 'decode_status',
        decodeId,
        status: 'Decoding…'
      }).catch(() => {});
    }

    if (articleResult?.ok && articleResult.body) {
      const titleLine = articleResult.title ? `Title: ${articleResult.title}\n` : '';
      const bylineLine = articleResult.byline ? `Byline: ${articleResult.byline}\n` : '';
      const meta = `[ARTICLE FETCHED FROM ${articleUrl} via ${articleResult.source}, ${articleResult.wordCount} words${articleResult.isPaywall ? ', PAYWALL DETECTED' : ''}]`;
      userMessage += `\n\n${meta}\n${titleLine}${bylineLine}\nARTICLE BODY:\n${articleResult.body}`;
    } else if (articleUrl && fetchSettings.enabled) {
      userMessage += `\n\n[ARTICLE FETCH FAILED for ${articleUrl}: ${articleResult?.error || articleResult?.source || 'unknown'}. Decoding using only the section context above.]`;
    }

    // Use explicit max_tokens from dev params, but grow it when verbosity is
    // verbose and the slider is still at default — otherwise respect the dial.
    const maxTokens = (decodeParams.verbosity === 2 && decodeParams.maxTokens <= 1500)
      ? Math.max(2200, decodeParams.maxTokens)
      : decodeParams.maxTokens;

    const apiBody = {
      model: decodeParams.model,
      max_tokens: maxTokens,
      temperature: decodeParams.temperature,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage }
      ]
    };
    if (decodeParams.topP !== 1.0) apiBody.top_p = decodeParams.topP;
    if (decodeParams.frequencyPenalty !== 0) apiBody.frequency_penalty = decodeParams.frequencyPenalty;
    if (decodeParams.presencePenalty !== 0) apiBody.presence_penalty = decodeParams.presencePenalty;
    if (decodeParams.seed != null) apiBody.seed = decodeParams.seed;

    // Cap API time so a hung response can never leave the card at "Decoding…".
    // Beyond this, fire decode_error with a clear message.
    const apiController = new AbortController();
    const apiTimer = setTimeout(() => apiController.abort(), 90000);
    let response;
    try {
      response = await fetch(OPENROUTER_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${OPENROUTER_KEY}`,
          'HTTP-Referer': 'chrome-extension://decode-web',
          'X-Title': 'Decode Web'
        },
        body: JSON.stringify(apiBody),
        signal: apiController.signal
      });
    } catch (e) {
      clearTimeout(apiTimer);
      if (e.name === 'AbortError') throw new Error('API timeout after 90s — try again or lower max tokens');
      throw e;
    }
    clearTimeout(apiTimer);

    const data = await response.json();
    if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));

    const responseText = data.choices?.[0]?.message?.content;
    if (!responseText) throw new Error('Empty response from API');

    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Could not parse response JSON');

    const decode = JSON.parse(jsonMatch[0]);

    // Send result to content script (floating card)
    chrome.tabs.sendMessage(tabId, {
      type: 'render_decode',
      decodeId,
      exhibitNum,
      label: decode.label,
      decode
    }).catch(() => {});

    // Send to sidebar (list entry)
    chrome.runtime.sendMessage({
      type: 'decode_completed',
      decodeId,
      exhibitNum,
      label: decode.label,
      decode,
      headlines
    }).catch(() => {});

  } catch (e) {
    // Send error to content script
    chrome.tabs.sendMessage(tabId, {
      type: 'decode_error',
      decodeId,
      error: e.message
    }).catch(() => {});

    // Send to sidebar
    chrome.runtime.sendMessage({
      type: 'decode_error',
      decodeId,
      error: e.message
    }).catch(() => {});
  }
}
