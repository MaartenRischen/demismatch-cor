// Offscreen document worker for article extraction.
//
// The service worker performs the fetch (it gets CORS exemption via the
// extension's host_permissions). The offscreen document's only job is to
// parse the returned HTML with DOMParser — a DOM API the MV3 service worker
// does not have — and run the article extractor against it.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'lens_offscreen_parse') return;

  try {
    const { html, url } = message;
    if (!html) {
      sendResponse({ ok: false, error: 'no html provided' });
      return;
    }
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    if (!doc || !doc.body) {
      sendResponse({ ok: false, error: 'parse failure' });
      return;
    }
    if (typeof window.lensExtractArticle !== 'function') {
      sendResponse({ ok: false, error: 'extractor not loaded' });
      return;
    }
    const data = window.lensExtractArticle(doc);
    data.url = url || data.url || '';
    sendResponse({ ok: true, ...data });
  } catch (e) {
    sendResponse({ ok: false, error: e?.message || String(e) });
  }
  return false; // sync response
});
