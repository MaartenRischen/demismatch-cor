// Content script — hover-to-select, click-to-decode, floating draggable cards
// Injected into the active tab by the background service worker

(function() {
  // Handle re-injection after extension reload
  if (window.__lensInjected) {
    const valid = (() => { try { return !!chrome.runtime?.id; } catch { return false; } })();
    if (valid) return;
    if (window.__lensCleanup) window.__lensCleanup();
  }
  window.__lensInjected = true;

  // ============================================================
  // CONFIG
  // ============================================================

  const CARD_W = 300;
  const MIN_SECTION_H = 60;
  const SKIP_TAGS = new Set(['SCRIPT','STYLE','NOSCRIPT','SVG','IFRAME','META','LINK','HEAD']);
  const INLINE_TAGS = new Set(['SPAN','A','EM','STRONG','B','I','U','SMALL','SUB','SUP','MARK','TIME','CODE','LABEL','ABBR','BR','WBR']);

  // ============================================================
  // STATE
  // ============================================================

  let selectionEnabled = false;
  let overlaysVisible = true;
  let hoveredSection = null;
  let decodeBtn = null;
  let hoverPreviewTag = null;
  let dragState = null;
  let hoverThrottle = 0;
  let nextId = 1;
  let exhibitCounter = 0;

  const decodes = new Map();    // element → { id }
  const decodeById = new Map(); // id → { element, card }
  let sectionCache = new WeakMap();

  // Section detection config (live-tunable from sidebar)
  const secConfig = {
    minH: 40,       // min height (px) to accept a block
    maxH: 0.75,     // max height as fraction of viewport
    minText: 15,    // min text chars to accept
    walkUp: 0,      // extra levels to walk up after first match
    skipH: true,    // skip headings (walk past them)
    skipI: true,    // skip images (walk past them)
    skipP: true,    // skip paragraphs (walk past them)
  };

  // Clear section cache on resize or config change
  function clearSectionCache() { sectionCache = new WeakMap(); }
  window.addEventListener('resize', clearSectionCache);

  // Keep exhibit tags + connectors aligned when layout shifts (resize, lazy-load,
  // accordion expansions, etc.). Cheap on each frame: ~O(decodes).
  function repositionAllDecorations() {
    for (const [, data] of decodeById) {
      if (data.tagEl && data.element) {
        positionExhibitTag(data.tagEl, data.element);
      }
    }
    for (const [id] of decodeById) { updateConnector(id); }
  }
  window.addEventListener('resize', repositionAllDecorations);
  window.addEventListener('scroll', repositionAllDecorations, { passive: true });

  // Kill any stuck hover state if the user leaves the document or switches tabs.
  window.addEventListener('blur', clearHover);
  document.addEventListener('mouseleave', clearHover);

  // ============================================================
  // SECTION DETECTION — find the meaningful container under cursor
  // ============================================================

  // Get visible text length (excludes script/style/noscript content)
  function visibleTextLen(el) {
    const scripts = el.querySelectorAll('script, style, noscript');
    let scriptLen = 0;
    scripts.forEach(s => { scriptLen += (s.textContent?.length || 0); });
    return Math.max(0, (el.textContent?.trim().length || 0) - scriptLen);
  }

  function findSection(target) {
    if (sectionCache.has(target)) return sectionCache.get(target);

    let el = target;
    let textOnlyFallback = null;

    while (el && el !== document.body && el !== document.documentElement) {
      if (el.nodeType !== 1) { el = el.parentElement; continue; }
      if (SKIP_TAGS.has(el.tagName)) { sectionCache.set(target, null); return null; }

      // Skip our own UI elements
      if (el.classList && (el.classList.contains('lens-decode-card') ||
          el.classList.contains('lens-decode-trigger') ||
          el.id === 'lens-svg-layer')) {
        sectionCache.set(target, null);
        return null;
      }

      const rect = el.getBoundingClientRect();
      const tag = el.tagName;

      // Too big — stop
      if (rect.height > window.innerHeight * secConfig.maxH) break;

      // Too small — walk up
      if (rect.height < 10 || rect.width < 30) { el = el.parentElement; continue; }

      // Skip inline elements — always walk up
      if (INLINE_TAGS.has(tag)) { el = el.parentElement; continue; }

      // Conditionally skip headings
      if (secConfig.skipH && /^(H[1-6])$/.test(tag)) { el = el.parentElement; continue; }

      // Conditionally skip paragraphs
      if (secConfig.skipP && tag === 'P') { el = el.parentElement; continue; }

      // Conditionally skip media elements
      if (secConfig.skipI && (tag === 'IMG' || tag === 'PICTURE' || tag === 'VIDEO')) {
        el = el.parentElement; continue;
      }

      const textLen = visibleTextLen(el);
      const hasText = textLen >= secConfig.minText;
      const hasMedia = !!el.querySelector('img, picture, video');
      // FIGURE removed — it's almost always a sub-wrapper, not the card itself
      const isSemantic = ['ARTICLE','SECTION','LI','ASIDE','MAIN','NAV','HEADER','FOOTER'].includes(tag);

      // Semantic containers and flex/grid children use a lower height threshold
      const effectiveMinH = isSemantic ? Math.min(secConfig.minH, 20) : secConfig.minH;
      if (rect.height < effectiveMinH) { el = el.parentElement; continue; }

      // Must have an actual heading tag to count as headline content.
      // No more "innerText > 20 chars" fallback — figcaptions and image credits were
      // triggering this and causing image-only wrappers to match Priority 1.
      const hasHeadlineContent = !!el.querySelector('h1,h2,h3,h4,h5,h6');

      // SMART DETECTION — converge on the same element regardless of hover target.
      // "Better too much than too little": after any match, climb to the outermost
      // parent that still qualifies as the same kind of thing.

      // Priority 1: Complete content card (visible text + media + real headline)
      if (hasText && hasMedia && hasHeadlineContent) {
        const result = walkUpExtra(expandCard(el), secConfig.walkUp);
        sectionCache.set(target, result);
        return result;
      }

      // Priority 2: Semantic container with content
      if (isSemantic && hasText) {
        const result = walkUpExtra(expandSemantic(el), secConfig.walkUp);
        sectionCache.set(target, result);
        return result;
      }

      // Priority 3: Flex/grid child with real content
      if (hasText && hasHeadlineContent && el.parentElement) {
        try {
          const pd = window.getComputedStyle(el.parentElement).display;
          if (pd.includes('flex') || pd.includes('grid')) {
            const result = walkUpExtra(expandCard(el), secConfig.walkUp);
            sectionCache.set(target, result);
            return result;
          }
        } catch {}
      }

      // Save the first text-only block as fallback
      if (!textOnlyFallback && hasText && rect.height >= secConfig.minH) {
        textOnlyFallback = el;
      }

      el = el.parentElement;
    }

    const result = textOnlyFallback ? walkUpExtra(textOnlyFallback, secConfig.walkUp) : null;
    sectionCache.set(target, result);
    return result;
  }

  // Count how many direct children of `el` independently satisfy the full card
  // test (visible text + media + real heading tag inside). Used to detect when
  // we have climbed into a grid/feed of sibling cards vs a wrapper around one
  // card that happens to have nested headings (e.g. main h2 + subtitle h3).
  function countChildCards(el) {
    let count = 0;
    for (const child of el.children) {
      if (child.nodeType !== 1) continue;
      if (SKIP_TAGS.has(child.tagName)) continue;
      const rect = child.getBoundingClientRect();
      if (rect.height < 20) continue;
      const hasText = visibleTextLen(child) >= secConfig.minText;
      const hasMedia = !!child.querySelector('img, picture, video');
      const hasHeadline = !!child.querySelector('h1,h2,h3,h4,h5,h6');
      if (hasText && hasMedia && hasHeadline) count++;
      if (count > 1) return count; // early exit; we only care whether >1
    }
    return count;
  }


  // Climb to the outermost ancestor that is still a valid "card"
  // (text + media + real headline, under maxH). Stops when the parent contains
  // MULTIPLE independent cards (it's a feed/grid, not a wrapper around one).
  // This is the correct heuristic for nested-heading cards (main headline +
  // subtitle inside a single card) — heading-count-delta falsely tripped on them.
  function expandCard(el) {
    let best = el;
    let p = el.parentElement;
    while (p && p !== document.body && p !== document.documentElement) {
      const rect = p.getBoundingClientRect();
      if (rect.height > window.innerHeight * secConfig.maxH) break;
      if (countChildCards(p) > 1) break;
      const hasText = visibleTextLen(p) >= secConfig.minText;
      const hasMedia = !!p.querySelector('img, picture, video');
      const hasHeadline = !!p.querySelector('h1,h2,h3,h4,h5,h6');
      if (hasText && hasMedia && hasHeadline) {
        best = p;
      }
      p = p.parentElement;
    }
    return best;
  }

  // Climb to the outermost semantic ancestor with text. Same sibling-cards guard.
  function expandSemantic(el) {
    const SEM = new Set(['ARTICLE','SECTION','LI','ASIDE','MAIN','NAV','HEADER','FOOTER']);
    let best = el;
    let p = el.parentElement;
    while (p && p !== document.body && p !== document.documentElement) {
      const rect = p.getBoundingClientRect();
      if (rect.height > window.innerHeight * secConfig.maxH) break;
      if (countChildCards(p) > 1) break;
      if (SEM.has(p.tagName) && visibleTextLen(p) >= secConfig.minText) {
        best = p;
      }
      p = p.parentElement;
    }
    return best;
  }

  // Optionally walk up N more levels from a matched element
  function walkUpExtra(el, levels) {
    if (levels <= 0) return el;
    let current = el;
    let remaining = levels;
    let p = current.parentElement;
    while (p && p !== document.body && remaining > 0) {
      const rect = p.getBoundingClientRect();
      if (rect.height > window.innerHeight * secConfig.maxH) break;
      if (rect.height >= 20) {
        current = p;
        remaining--;
      }
      p = p.parentElement;
    }
    return current;
  }

  // ============================================================
  // TEXT EXTRACTION
  // ============================================================

  function cleanText(el) {
    const clone = el.cloneNode(true);
    clone.querySelectorAll('nav, script, style, button, form, input, time, img, picture, figure, video, svg, [aria-hidden="true"]').forEach(s => s.remove());
    return clone.textContent?.trim().replace(/\s+/g, ' ') || '';
  }

  function getHeadlines(el) {
    const headlines = [];
    const seen = new Set();
    const add = (text) => {
      if (text.length < 10 || text.length > 500) return;
      const norm = text.toLowerCase().slice(0, 60);
      if (seen.has(norm)) return;
      seen.add(norm);
      headlines.push(text.slice(0, 300));
    };

    el.querySelectorAll('h1, h2, h3, h4, h5').forEach(h => add(cleanText(h)));
    el.querySelectorAll('a').forEach(a => {
      if (!a.querySelector('h1,h2,h3,h4,h5')) add(cleanText(a));
    });

    // Fallback: element's own text
    if (headlines.length === 0) {
      const text = cleanText(el);
      if (text.length >= 15) headlines.push(text.slice(0, 500));
    }
    return headlines;
  }

  // ============================================================
  // STYLE INJECTION
  // ============================================================

  function injectStyles() {
    if (document.getElementById('lens-styles')) return;
    const style = document.createElement('style');
    style.id = 'lens-styles';
    style.textContent = `
      .lens-hover-outline {
        outline: 1.5px dashed rgba(212, 168, 75, 0.4) !important;
        outline-offset: 2px;
      }
      .lens-decoded-section { outline: none !important; }

      .lens-exhibit-tag {
        position: absolute;
        z-index: 10004;
        background: #1A1A19;
        color: #E24B4A;
        font-family: 'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, 'Courier New', monospace;
        font-size: 9px;
        font-weight: 600;
        letter-spacing: 0.12em;
        padding: 3px 6px 3px 5px;
        border-radius: 4px;
        pointer-events: auto;
        cursor: pointer;
        user-select: none;
        text-transform: none;
        line-height: 1;
      }
      .lens-exhibit-tag.lens-exhibit-preview {
        color: rgba(226, 75, 74, 0.55);
        pointer-events: none;
        cursor: default;
      }

      .lens-decode-trigger {
        position: absolute; z-index: 10003;
        background: rgba(8, 8, 8, 0.85);
        backdrop-filter: blur(14px) saturate(1.2); -webkit-backdrop-filter: blur(14px) saturate(1.2);
        color: #D4A84B;
        border: 1px solid rgba(212, 168, 75, 0.35);
        border-radius: 5px; padding: 5px 12px;
        font-size: 10px; font-weight: 500; text-transform: uppercase;
        letter-spacing: 2px; cursor: pointer;
        font-family: 'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, 'Courier New', monospace;
        box-shadow: 0 4px 16px rgba(0,0,0,0.55);
        transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease;
        display: none;
      }
      .lens-decode-trigger:hover {
        background: rgba(20, 18, 16, 0.92);
        border-color: rgba(212, 168, 75, 0.7);
        color: #ffffff;
        transform: scale(1.04);
      }

      .lens-decode-card {
        position: absolute; width: ${CARD_W}px; z-index: 10001;
        background: rgba(8, 8, 8, 0.9);
        backdrop-filter: blur(14px) saturate(1.3); -webkit-backdrop-filter: blur(14px) saturate(1.3);
        border: 1px solid rgba(224, 216, 204, 0.14);
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 12px 40px rgba(0,0,0,0.55), 0 2px 8px rgba(0,0,0,0.25);
        font-family: 'Spectral', Georgia, 'Times New Roman', serif;
        color: rgba(224, 216, 204, 1);
        user-select: none; cursor: grab;
        transition: box-shadow 0.2s ease, transform 0.2s ease, border-color 0.2s ease;
        -webkit-font-smoothing: antialiased;
      }
      .lens-decode-card:hover {
        border-color: rgba(224, 216, 204, 0.24);
        box-shadow: 0 16px 48px rgba(0,0,0,0.65), 0 4px 12px rgba(0,0,0,0.3);
      }
      .lens-decode-card.dragging {
        cursor: grabbing; transform: scale(1.02);
        box-shadow: 0 20px 56px rgba(0,0,0,0.75), 0 8px 18px rgba(0,0,0,0.4);
      }

      .lens-card-topbar {
        display: flex; align-items: center; justify-content: space-between;
        gap: 8px;
        background: #1A1A19;
        padding: 6px 8px 6px 10px;
      }
      .lens-card-topbar-left {
        display: flex; align-items: baseline; gap: 6px; flex: 1; min-width: 0;
        font-family: 'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, 'Courier New', monospace;
        font-size: 9px; font-weight: 600;
        letter-spacing: 0.1em; text-transform: uppercase;
        color: #D4A84B;
        overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
      }
      .lens-card-exnum { font-weight: 600; flex-shrink: 0; }
      .lens-card-brand {
        font-family: 'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, 'Courier New', monospace;
        font-size: 8px; font-weight: 400;
        letter-spacing: 0.2em; text-transform: uppercase;
        color: rgba(224, 216, 204, 0.3);
        flex-shrink: 0;
      }
      .lens-card-close {
        background: transparent; border: 1px solid rgba(224, 216, 204, 0.15);
        color: rgba(224, 216, 204, 0.5);
        font-size: 13px; width: 22px; height: 22px; border-radius: 0;
        cursor: pointer; display: flex; align-items: center; justify-content: center;
        line-height: 1; font-family: inherit; flex-shrink: 0; padding: 0;
        transition: border-color 0.15s ease, color 0.15s ease;
      }
      .lens-card-close:hover {
        border-color: rgba(224, 216, 204, 0.4);
        color: rgba(224, 216, 204, 0.95);
      }

      /* Hero pattern name — deep ink red, the biggest thing in the card */
      .lens-card-hero {
        padding: 18px 18px 14px;
        font-family: 'Spectral', Georgia, 'Times New Roman', serif;
        font-size: 24px;
        font-weight: 500;
        line-height: 1.15;
        letter-spacing: -0.005em;
        color: #B83535;
        margin: 0;
        cursor: pointer;
      }
      .lens-card-hero-divider {
        height: 0;
        border: none;
        border-top: 1px solid rgba(224, 216, 204, 0.1);
        margin: 0;
      }

      .lens-card-body {
        padding: 16px 18px 14px;
      }
      .lens-card-label {
        font-family: 'Spectral', Georgia, 'Times New Roman', serif;
        font-size: 15px; line-height: 1.55; font-weight: 400;
        color: rgba(224, 216, 204, 1);
        letter-spacing: 0;
        margin: 0;
      }
      .lens-card-divider {
        height: 0; border: none;
        border-top: 1px dashed rgba(224, 216, 204, 0.15);
        margin: 14px 0 12px;
      }
      .lens-card-absolution {
        font-family: 'Spectral', Georgia, 'Times New Roman', serif;
        font-size: 13px; line-height: 1.55; font-weight: 300;
        color: rgba(224, 216, 204, 0.85);
        letter-spacing: 0;
        margin: 0;
      }

      .lens-card-footer {
        display: flex; align-items: center; justify-content: space-between;
        gap: 12px;
        padding: 0 18px 14px;
      }
      .lens-card-footer button {
        background: transparent;
        border: none;
        padding: 4px 0;
        cursor: pointer;
        font-family: 'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, 'Courier New', monospace;
        font-size: 9px;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        transition: color 0.15s ease;
      }
      .lens-card-dismiss { color: rgba(224, 216, 204, 0.45); font-weight: 400; }
      .lens-card-dismiss:hover { color: rgba(224, 216, 204, 0.9); }
      .lens-card-open-breakdown { color: #D4A84B; font-weight: 600; }
      .lens-card-open-breakdown:hover { color: #ffffff; }

      #lens-svg-layer {
        position: absolute; top: 0; left: 0;
        width: 100%; height: 100%;
        z-index: 10000; pointer-events: none; overflow: visible;
      }

      /* Connector states.
           .decoding: gradient stroke + dashed stream pulsing inward (tip →
             card). Signals "reading / thinking." Set via SVG attributes +
             CSS dasharray/animation here.
           default (post-gen): solid red line, no dashes, no animation. The
             stroke attribute is rewritten to a flat red by JS when .decoding
             is removed (see updateCardContent / showCardError).
         Line uses pathLength="100" so dasharray % is uniform during decoding.
      */
      @keyframes lens-conn-pulse-in {
        from { stroke-dashoffset: 0; }
        to   { stroke-dashoffset: 100; }
      }
      .lens-connector-group.decoding .lens-connector-line {
        stroke-dasharray: 14 86;
        animation: lens-conn-pulse-in 1.0s linear infinite;
      }
      .lens-connector-group { will-change: transform; }

      /* Arrow breath — always on, gentle. Gives the arrowhead life so it
         feels like the destination is receiving (post-gen) or anticipating
         (decoding). Slight brightness + scale pulse. */
      @keyframes lens-arrow-breath {
        0%, 100% { opacity: 0.88; transform: scale(1); }
        50%      { opacity: 1;    transform: scale(1.08); }
      }
      #lens-arrow path {
        transform-origin: 5px 5px;
        transform-box: fill-box;
        animation: lens-arrow-breath 1.4s ease-in-out infinite;
      }

      /* Decoding-state animation: bright signal arc sweeps around the card's
         border. Implemented as a conic-gradient pseudo-element masked to only
         show the padding ring. @property registers the angle as an animatable
         <angle> so the interpolation is smooth (without it, the conic-gradient
         would jump frame-by-frame). */
      @property --lens-trace-angle {
        syntax: '<angle>';
        initial-value: 0deg;
        inherits: false;
      }
      .lens-decode-card.decoding::before {
        content: '';
        position: absolute;
        inset: -1px;
        border-radius: 9px;
        padding: 2px;
        pointer-events: none;
        background:
          conic-gradient(
            from var(--lens-trace-angle, 0deg),
            transparent 0deg,
            transparent 270deg,
            rgba(226, 75, 74, 0.55) 295deg,
            #ff6464 320deg,
            #ffd0d0 348deg,
            #ff6464 354deg,
            rgba(226, 75, 74, 0.55) 360deg
          );
        -webkit-mask:
          linear-gradient(#000, #000) content-box,
          linear-gradient(#000, #000);
        -webkit-mask-composite: xor;
                mask:
          linear-gradient(#000, #000) content-box,
          linear-gradient(#000, #000);
                mask-composite: exclude;
        animation: lens-card-trace 1.6s linear infinite;
        z-index: 100;
      }
      @keyframes lens-card-trace {
        to { --lens-trace-angle: 360deg; }
      }
    `;
    document.head.appendChild(style);

    // SVG layer for connectors
    if (!document.getElementById('lens-svg-layer')) {
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.id = 'lens-svg-layer';
      const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');

      // 3D arrow gradient — light at top-left, dark at bottom-right gives the
      // marker a beveled metallic look from a steady "above" light source.
      const arrowGrad = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
      arrowGrad.setAttribute('id', 'lens-arrow-grad');
      arrowGrad.setAttribute('x1', '0'); arrowGrad.setAttribute('y1', '0');
      arrowGrad.setAttribute('x2', '0'); arrowGrad.setAttribute('y2', '1');
      const ag1 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
      ag1.setAttribute('offset', '0%'); ag1.setAttribute('stop-color', '#ff8a8a');
      const ag2 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
      ag2.setAttribute('offset', '50%'); ag2.setAttribute('stop-color', '#E24B4A');
      const ag3 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
      ag3.setAttribute('offset', '100%'); ag3.setAttribute('stop-color', '#7a1f1f');
      arrowGrad.appendChild(ag1); arrowGrad.appendChild(ag2); arrowGrad.appendChild(ag3);
      defs.appendChild(arrowGrad);

      // Soft blur filter for the depth-shadow path under each connector line.
      const blurFilter = document.createElementNS('http://www.w3.org/2000/svg', 'filter');
      blurFilter.setAttribute('id', 'lens-conn-blur');
      blurFilter.setAttribute('x', '-50%'); blurFilter.setAttribute('y', '-50%');
      blurFilter.setAttribute('width', '200%'); blurFilter.setAttribute('height', '200%');
      const fg = document.createElementNS('http://www.w3.org/2000/svg', 'feGaussianBlur');
      fg.setAttribute('in', 'SourceGraphic');
      fg.setAttribute('stdDeviation', '2.5');
      blurFilter.appendChild(fg);
      defs.appendChild(blurFilter);

      // Arrow marker — filled triangle with the 3D gradient, substantial size.
      const marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
      marker.setAttribute('id', 'lens-arrow');
      marker.setAttribute('viewBox', '0 0 10 10');
      marker.setAttribute('refX', '10');
      marker.setAttribute('refY', '5');
      marker.setAttribute('markerWidth', '12');
      marker.setAttribute('markerHeight', '12');
      marker.setAttribute('orient', 'auto-start-reverse');
      const arrowPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      arrowPath.setAttribute('d', 'M 0 0 L 10 5 L 0 10 z');
      arrowPath.setAttribute('fill', 'url(#lens-arrow-grad)');
      arrowPath.setAttribute('stroke', '#5a1414');
      arrowPath.setAttribute('stroke-width', '0.4');
      arrowPath.setAttribute('stroke-linejoin', 'round');
      marker.appendChild(arrowPath);
      defs.appendChild(marker);

      svg.appendChild(defs);
      document.body.appendChild(svg);
      if (window.getComputedStyle(document.body).position === 'static') {
        document.body.style.position = 'relative';
      }
    }

    // Reusable "Decode" trigger button
    if (!decodeBtn) {
      decodeBtn = document.createElement('button');
      decodeBtn.className = 'lens-decode-trigger';
      decodeBtn.textContent = 'Decode';
      decodeBtn.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
      });
      decodeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (hoveredSection && !decodes.has(hoveredSection)) {
          triggerDecode(hoveredSection);
        }
      });
      document.body.appendChild(decodeBtn);
    }
  }

  // ============================================================
  // HOVER DETECTION
  // ============================================================

  function handleHover(e) {
    if (dragState) return;
    if (!selectionEnabled || !overlaysVisible) return;

    const now = Date.now();
    if (now - hoverThrottle < 40) return;
    hoverThrottle = now;

    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el) return;

    // If hovering our decode button, keep current state
    if (el === decodeBtn || el.closest('.lens-decode-trigger')) return;

    // If hovering a decode card, clear hover
    if (el.closest('.lens-decode-card')) {
      clearHover();
      return;
    }

    const section = findSection(el);
    if (section === hoveredSection) return;

    clearHover();
    hoveredSection = section;

    // Only highlight if not already decoded
    if (section && !decodes.has(section)) {
      section.classList.add('lens-hover-outline');
      showDecodeButton(section);
      showHoverPreviewTag(section);
    }
  }

  function clearHover() {
    if (hoveredSection) {
      hoveredSection.classList.remove('lens-hover-outline');
      hoveredSection = null;
    }
    hideDecodeButton();
    hideHoverPreviewTag();
  }

  function showDecodeButton(section) {
    if (!decodeBtn) return;
    const rect = section.getBoundingClientRect();
    // Document coords so the button stays anchored to the section under scroll.
    const top = rect.top + window.scrollY + 4;
    const rightEdge = rect.right + window.scrollX;
    const pageW = document.documentElement.scrollWidth;
    const left = Math.max(8, Math.min(rightEdge - 72, pageW - 80));
    decodeBtn.style.top = top + 'px';
    decodeBtn.style.left = left + 'px';
    decodeBtn.style.display = 'block';
  }

  function hideDecodeButton() {
    if (decodeBtn) decodeBtn.style.display = 'none';
  }

  // ============================================================
  // DECODE TRIGGER
  // ============================================================

  function triggerDecode(section) {
    const id = nextId++;
    exhibitCounter++;
    const exhibitNum = String(exhibitCounter).padStart(2, '0');
    const headlines = getHeadlines(section);
    const text = cleanText(section).slice(0, 3000);
    const articleUrl = findArticleUrl(section);

    // Mark section as decoded (no outline — the tag + arrow carry the signal)
    section.classList.remove('lens-hover-outline');
    section.classList.add('lens-decoded-section');
    section.dataset.lensEx = exhibitNum;
    hoveredSection = null;
    hideDecodeButton();
    hideHoverPreviewTag();

    // Create exhibit tag anchored at section's top-left (clickable — opens breakdown)
    const tagEl = createExhibitTag(section, exhibitNum, id);

    // Create floating card (loading state, with exhibit number in the header strip)
    const card = createDecodeCard(id, section, exhibitNum);
    decodes.set(section, { id });
    decodeById.set(id, { element: section, card, tagEl, exhibitNum, headlines, text, articleUrl });

    // Draw connector from card to the tag (tag is the anchor, not the section body)
    drawConnector(id, tagEl, card);

    // Send to background for API call
    chrome.runtime.sendMessage({
      type: 'section_clicked',
      decodeId: id,
      exhibitNum,
      headlines,
      text,
      articleUrl
    }).catch(() => {});
  }

  // Find the article URL the decoded section is linking to. Prefer links that
  // wrap a heading. Skip social-share, javascript:, mailto:, and same-page
  // anchor targets.
  function findArticleUrl(section) {
    const links = section.querySelectorAll('a[href]');
    if (!links.length) return null;

    // Pass 1: links wrapping a heading
    for (const a of links) {
      if (a.querySelector('h1,h2,h3,h4,h5,h6')) {
        const url = absolutize(a.href);
        if (isArticleUrl(url)) return url;
      }
    }
    // Pass 2: longest text-content link
    let best = null;
    let bestLen = 0;
    for (const a of links) {
      const t = (a.textContent || '').trim();
      if (t.length <= bestLen) continue;
      const url = absolutize(a.href);
      if (!isArticleUrl(url)) continue;
      best = url;
      bestLen = t.length;
    }
    return best;
  }

  function absolutize(href) {
    try { return new URL(href, location.origin).href; } catch { return null; }
  }

  function isArticleUrl(url) {
    if (!url) return false;
    if (url.startsWith('javascript:') || url.startsWith('mailto:') || url.startsWith('tel:')) return false;
    if (url.startsWith('#') || url === location.href + '#' || url === location.href) return false;
    // Skip share-intent URLs
    if (/(twitter\.com\/intent|facebook\.com\/sharer|whatsapp\.com\/send|reddit\.com\/submit|linkedin\.com\/share)/i.test(url)) return false;
    return true;
  }

  // Ask the runtime to open the side panel and jump to this exhibit's breakdown card.
  function requestOpenBreakdownInPanel(decodeId) {
    chrome.runtime.sendMessage({ type: 'request_open_sidepanel' }).catch(() => {});
    chrome.runtime.sendMessage({ type: 'open_breakdown_in_panel', decodeId }).catch(() => {});
  }

  // Create a floating exhibit tag at the top-left corner of the given element (page coords).
  function createExhibitTag(el, exhibitNum, decodeId) {
    const tag = document.createElement('div');
    tag.className = 'lens-exhibit-tag';
    tag.textContent = `EX·${exhibitNum}`;
    tag.dataset.decodeId = decodeId;
    tag.title = 'Open breakdown';
    tag.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      requestOpenBreakdownInPanel(decodeId);
    });
    document.body.appendChild(tag);
    positionExhibitTag(tag, el);
    return tag;
  }

  function positionExhibitTag(tag, el) {
    const rect = el.getBoundingClientRect();
    const sx = window.scrollX;
    const sy = window.scrollY;
    tag.style.left = (rect.left + sx) + 'px';
    tag.style.top = (rect.top + sy) + 'px';
  }

  // Hover preview — small amber EX·? at top-left of the hovered section.
  function showHoverPreviewTag(el) {
    if (!hoverPreviewTag) {
      hoverPreviewTag = document.createElement('div');
      hoverPreviewTag.className = 'lens-exhibit-tag lens-exhibit-preview';
      hoverPreviewTag.textContent = 'EX·?';
      document.body.appendChild(hoverPreviewTag);
    }
    hoverPreviewTag.style.display = 'block';
    positionExhibitTag(hoverPreviewTag, el);
  }

  function hideHoverPreviewTag() {
    if (hoverPreviewTag) hoverPreviewTag.style.display = 'none';
  }

  // ============================================================
  // FLOATING DECODE CARDS
  // ============================================================

  // Find a position for the card that doesn't overlap the source or any existing cards/sections
  function findCardPosition(sourceEl) {
    const CARD_H_EST = 110;
    const GAP = 18;
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    const pageW = document.documentElement.scrollWidth;
    const src = sourceEl.getBoundingClientRect();

    // Collect all occupied rects (page coords, with padding)
    const occupied = [];
    // Source section
    occupied.push({
      l: src.left + scrollX - GAP, t: src.top + scrollY - GAP,
      r: src.right + scrollX + GAP, b: src.bottom + scrollY + GAP
    });
    // All existing decoded sections
    for (const [el] of decodes) {
      if (el === sourceEl) continue;
      const r = el.getBoundingClientRect();
      occupied.push({ l: r.left + scrollX - GAP, t: r.top + scrollY - GAP,
        r: r.right + scrollX + GAP, b: r.bottom + scrollY + GAP });
    }
    // All existing cards
    for (const [, data] of decodeById) {
      const r = data.card.getBoundingClientRect();
      occupied.push({ l: r.left + scrollX - GAP, t: r.top + scrollY - GAP,
        r: r.right + scrollX + GAP, b: r.bottom + scrollY + GAP });
    }

    function hits(cx, cy) {
      const cl = cx, ct = cy, cr = cx + CARD_W, cb = cy + CARD_H_EST;
      for (const o of occupied) {
        if (cl < o.r && cr > o.l && ct < o.b && cb > o.t) return true;
      }
      return false;
    }

    const sl = src.left + scrollX, sr = src.right + scrollX;
    const st = src.top + scrollY, sb = src.bottom + scrollY;
    const smx = (sl + sr) / 2;

    // Build candidate list — prefer right if source is left-ish, vice versa
    const rightFirst = smx < pageW / 2;
    const candidates = [];

    if (rightFirst) {
      candidates.push({ x: sr + GAP, y: st });
      candidates.push({ x: sr + GAP, y: st + (sb - st) / 2 - CARD_H_EST / 2 });
      candidates.push({ x: sl - CARD_W - GAP, y: st });
      candidates.push({ x: sl - CARD_W - GAP, y: st + (sb - st) / 2 - CARD_H_EST / 2 });
    } else {
      candidates.push({ x: sl - CARD_W - GAP, y: st });
      candidates.push({ x: sl - CARD_W - GAP, y: st + (sb - st) / 2 - CARD_H_EST / 2 });
      candidates.push({ x: sr + GAP, y: st });
      candidates.push({ x: sr + GAP, y: st + (sb - st) / 2 - CARD_H_EST / 2 });
    }
    // Below source
    candidates.push({ x: sl, y: sb + GAP });
    candidates.push({ x: sr - CARD_W, y: sb + GAP });
    // Above source
    candidates.push({ x: sl, y: st - CARD_H_EST - GAP });
    candidates.push({ x: sr - CARD_W, y: st - CARD_H_EST - GAP });
    // Further out right/left
    candidates.push({ x: sr + GAP + CARD_W + GAP, y: st });
    candidates.push({ x: sl - (CARD_W + GAP) * 2, y: st });

    // Clamp candidates to the viewport (not just the page). On scroll the user
    // sees the viewport, so an absolute-positioned card at doc-coord x must fall
    // inside [scrollX+8, scrollX+innerWidth-CARD_W-8] to be visible now.
    const viewLeft = window.scrollX + 8;
    const viewRight = window.scrollX + window.innerWidth - CARD_W - 8;
    const viewTop = window.scrollY + 8;

    function clampX(x) {
      // Never below 8px from viewport left, never past viewport right minus card minus 8px.
      // If pageW < viewport (rare), fall back to page bounds.
      const min = Math.max(8, Math.min(viewLeft, pageW - CARD_W - 8));
      const max = Math.min(viewRight, pageW - CARD_W - 8);
      if (max < min) return min;
      return Math.max(min, Math.min(x, max));
    }

    for (const c of candidates) {
      c.x = clampX(c.x);
      // If candidate is above the viewport (rare), drop to below-source instead.
      if (c.y < viewTop) c.y = sb + GAP;
      if (!hits(c.x, c.y)) return c;
    }

    // Fallback: scan downward from below source
    for (let dy = 0; dy < 1200; dy += CARD_H_EST + GAP) {
      const cx = rightFirst ? sr + GAP : sl - CARD_W - GAP;
      const cy = sb + GAP + dy;
      const fx = clampX(cx);
      if (!hits(fx, cy)) return { x: fx, y: cy };
    }

    // Last resort: pin to top-left of the viewport.
    return { x: clampX(12 + window.scrollX), y: viewTop + 4 };
  }

  function createDecodeCard(id, sourceEl, exhibitNum) {
    const { x, y } = findCardPosition(sourceEl);

    const card = document.createElement('div');
    card.className = 'lens-decode-card decoding';
    card.dataset.decodeId = id;
    card.style.left = x + 'px';
    card.style.top = y + 'px';

    // ── Header strip: EX·NN · pattern_name  |  LENS  |  × ──
    const topbar = document.createElement('div');
    topbar.className = 'lens-card-topbar';

    const topLeft = document.createElement('div');
    topLeft.className = 'lens-card-topbar-left';
    const exNum = document.createElement('span');
    exNum.className = 'lens-card-exnum';
    exNum.textContent = `EX·${exhibitNum}`;
    topLeft.appendChild(exNum);

    const brand = document.createElement('span');
    brand.className = 'lens-card-brand';
    brand.textContent = 'LENS';

    const close = document.createElement('button');
    close.className = 'lens-card-close';
    close.textContent = '\u00d7';
    close.addEventListener('click', (e) => {
      e.stopPropagation();
      removeDecode(id);
    });
    close.addEventListener('mousedown', (e) => e.stopPropagation());

    topbar.appendChild(topLeft);
    topbar.appendChild(brand);
    topbar.appendChild(close);
    card.appendChild(topbar);

    // ── Hero pattern name (filled once the decode arrives) ──
    const hero = document.createElement('p');
    hero.className = 'lens-card-hero';
    hero.textContent = '';
    card.appendChild(hero);

    const heroDivider = document.createElement('hr');
    heroDivider.className = 'lens-card-hero-divider';
    heroDivider.style.display = 'none';
    card.appendChild(heroDivider);

    // ── Body: label + divider + absolution ──
    const body = document.createElement('div');
    body.className = 'lens-card-body';

    const label = document.createElement('p');
    label.className = 'lens-card-label';
    label.textContent = 'Decoding\u2026';
    body.appendChild(label);

    const divider = document.createElement('hr');
    divider.className = 'lens-card-divider';
    divider.style.display = 'none';
    body.appendChild(divider);

    const absolution = document.createElement('p');
    absolution.className = 'lens-card-absolution';
    absolution.textContent = '';
    absolution.style.display = 'none';
    body.appendChild(absolution);

    card.appendChild(body);

    // ── Footer: DISMISS | OPEN BREAKDOWN → ──
    const footer = document.createElement('div');
    footer.className = 'lens-card-footer';

    const dismiss = document.createElement('button');
    dismiss.className = 'lens-card-dismiss';
    dismiss.textContent = 'Dismiss';
    dismiss.addEventListener('click', (e) => {
      e.stopPropagation();
      removeDecode(id);
    });
    dismiss.addEventListener('mousedown', (e) => e.stopPropagation());

    const openBd = document.createElement('button');
    openBd.className = 'lens-card-open-breakdown';
    openBd.textContent = 'Open breakdown →';
    openBd.addEventListener('click', (e) => {
      e.stopPropagation();
      requestOpenBreakdownInPanel(id);
    });
    openBd.addEventListener('mousedown', (e) => e.stopPropagation());

    footer.appendChild(dismiss);
    footer.appendChild(openBd);
    card.appendChild(footer);

    document.body.appendChild(card);

    // Track mousedown position so a genuine drag doesn't also fire a click-through.
    let lastMouseDown = null;

    // Drag setup — don't start drag on any interactive footer/close button
    card.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      if (e.button !== 0) return;
      lastMouseDown = { x: e.clientX, y: e.clientY };
      e.preventDefault();
      card.classList.add('dragging');
      document.body.style.userSelect = 'none';
      dragState = {
        card, id, sourceEl,
        startX: e.clientX,
        startY: e.clientY,
        origLeft: parseFloat(card.style.left),
        origTop: parseFloat(card.style.top)
      };
    });

    // Click anywhere on the card body (not topbar/drag, not DISMISS, not close, not
    // OPEN BREAKDOWN — the latter three fire their own handlers) → open side panel
    // and highlight the matching breakdown card.
    card.addEventListener('click', (e) => {
      if (e.target.closest('.lens-card-topbar, .lens-card-dismiss, .lens-card-close, .lens-card-open-breakdown')) return;
      if (lastMouseDown) {
        const dx = Math.abs(e.clientX - lastMouseDown.x);
        const dy = Math.abs(e.clientY - lastMouseDown.y);
        if (dx > 5 || dy > 5) return; // treat as drag, not click
      }
      requestOpenBreakdownInPanel(id);
    });

    return card;
  }

  // Pattern names come from the LLM in ALL CAPS.
  // The hero block renders them in sentence case — capital first letter, rest lowercase.
  function sentenceCasePattern(s) {
    if (!s) return '';
    const lower = String(s).toLowerCase();
    return lower.charAt(0).toUpperCase() + lower.slice(1);
  }

  function updateCardContent(id, labelText, patternName, absolutionText) {
    const data = decodeById.get(id);
    if (!data) return;
    const card = data.card;
    // Result is in — kill the signal-around-the-frame loader on the card AND
    // flip the connector to its post-gen state (solid red, no animation).
    card.classList.remove('decoding');
    const connGroup = document.querySelector(`.lens-connector-group[data-decode-id="${id}"]`);
    if (connGroup) {
      connGroup.classList.remove('decoding');
      flattenConnectorStroke(id);
    }

    const hero = card.querySelector('.lens-card-hero');
    const heroDivider = card.querySelector('.lens-card-hero-divider');
    if (hero) {
      hero.textContent = sentenceCasePattern(patternName);
    }
    if (heroDivider) {
      heroDivider.style.display = patternName ? '' : 'none';
    }

    const label = card.querySelector('.lens-card-label');
    if (label) {
      label.textContent = labelText || '';
      label.style.color = '';
    }

    const divider = card.querySelector('.lens-card-divider');
    const absolution = card.querySelector('.lens-card-absolution');
    if (absolutionText && absolution) {
      absolution.textContent = absolutionText;
      absolution.style.display = '';
      if (divider) divider.style.display = '';
    } else if (absolution) {
      absolution.style.display = 'none';
      if (divider) divider.style.display = 'none';
    }

    updateConnector(id);
  }

  function showCardError(id, error) {
    const data = decodeById.get(id);
    if (!data) return;
    data.card.classList.remove('decoding');
    const connGroup = document.querySelector(`.lens-connector-group[data-decode-id="${id}"]`);
    if (connGroup) {
      connGroup.classList.remove('decoding');
      flattenConnectorStroke(id);
    }
    const label = data.card.querySelector('.lens-card-label');
    if (label) {
      label.textContent = 'Error: ' + (error || 'decode failed');
      label.style.color = 'rgba(205, 120, 120, 0.9)';
    }
  }

  function removeDecode(id) {
    const data = decodeById.get(id);
    if (!data) return;

    data.card.remove();
    if (data.tagEl) data.tagEl.remove();
    data.element.classList.remove('lens-decoded-section');
    delete data.element.dataset.lensEx;
    decodes.delete(data.element);
    decodeById.delete(id);

    // Remove SVG connector group + its per-connector gradient
    const connGroup = document.querySelector(`.lens-connector-group[data-decode-id="${id}"]`);
    if (connGroup) connGroup.remove();
    const grad = document.getElementById(`lens-conn-grad-${id}`);
    if (grad) grad.remove();

    // Notify extension
    chrome.runtime.sendMessage({ type: 'decode_removed', decodeId: id }).catch(() => {});
  }

  // ============================================================
  // SVG CONNECTORS (thick arrows connecting cards to sources)
  // ============================================================

  // Pick the visual anchor INSIDE a decoded section: middle of the largest
  // image, or middle of the largest heading, or section center as fallback.
  // The arrowhead lands here so it points at the content, not at the corner.
  function findContentAnchor(section) {
    const sx = window.scrollX;
    const sy = window.scrollY;
    // Largest visible media first
    const media = section.querySelectorAll('img, picture, video');
    let bestEl = null, bestArea = 0;
    for (const m of media) {
      const r = m.getBoundingClientRect();
      if (r.width < 60 || r.height < 40) continue;
      const a = r.width * r.height;
      if (a > bestArea) { bestEl = m; bestArea = a; }
    }
    if (bestEl) {
      const r = bestEl.getBoundingClientRect();
      return { x: r.left + sx + r.width / 2, y: r.top + sy + r.height / 2 };
    }
    // Largest heading
    const hs = section.querySelectorAll('h1,h2,h3,h4,h5,h6');
    bestEl = null; bestArea = 0;
    for (const h of hs) {
      const r = h.getBoundingClientRect();
      const a = r.width * r.height;
      if (a > bestArea) { bestEl = h; bestArea = a; }
    }
    if (bestEl) {
      const r = bestEl.getBoundingClientRect();
      return { x: r.left + sx + r.width / 2, y: r.top + sy + r.height / 2 };
    }
    // Fall back to section center
    const r = section.getBoundingClientRect();
    return { x: r.left + sx + r.width / 2, y: r.top + sy + r.height / 2 };
  }

  // drawConnector — second arg is the ANCHOR element (kept for signature
  // compatibility with the call site). The actual anchor point is computed
  // each updateConnector via findContentAnchor on data.element.
  function drawConnector(id, _anchorEl, card) {
    const svg = document.getElementById('lens-svg-layer');
    if (!svg) return;

    // Remove existing for this id (gradient + group)
    svg.querySelectorAll(`[data-decode-id="${id}"]`).forEach(el => el.remove());
    const oldGrad = document.getElementById(`lens-conn-grad-${id}`);
    if (oldGrad) oldGrad.remove();

    // Per-connector linear gradient. Endpoints get rewritten on every
    // updateConnector to match path direction. Keeps gradient flowing card→tip.
    const grad = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
    grad.setAttribute('id', `lens-conn-grad-${id}`);
    grad.setAttribute('gradientUnits', 'userSpaceOnUse');
    const stop1 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
    stop1.setAttribute('offset', '0%'); stop1.setAttribute('stop-color', '#7a1f1f');
    const stop2 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
    stop2.setAttribute('offset', '100%'); stop2.setAttribute('stop-color', '#ff6a6a');
    grad.appendChild(stop1); grad.appendChild(stop2);
    svg.querySelector('defs').appendChild(grad);

    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.dataset.decodeId = id;
    g.classList.add('lens-connector-group', 'decoding');

    // Depth shadow under the line — blurred dark stroke gives the connector
    // a subtle elevation off the page.
    const shadowPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    shadowPath.classList.add('lens-connector-shadow');
    shadowPath.setAttribute('fill', 'none');
    shadowPath.setAttribute('stroke', 'rgba(0,0,0,0.35)');
    shadowPath.setAttribute('stroke-linecap', 'round');
    shadowPath.setAttribute('filter', 'url(#lens-conn-blur)');
    g.appendChild(shadowPath);

    // Main animated line — gradient stroke, dashed, pulse keyframe in CSS.
    // pathLength="100" normalizes stroke-dasharray to percentages so the same
    // CSS dash spec works for any path length.
    const linePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    linePath.classList.add('lens-connector-line');
    linePath.setAttribute('fill', 'none');
    linePath.setAttribute('stroke', `url(#lens-conn-grad-${id})`);
    linePath.setAttribute('stroke-linecap', 'round');
    linePath.setAttribute('stroke-linejoin', 'round');
    linePath.setAttribute('marker-end', 'url(#lens-arrow)');
    linePath.setAttribute('pathLength', '100');
    g.appendChild(linePath);

    svg.appendChild(g);
    updateConnector(id);
  }

  // Connector style config (updated by design panel).
  const connCfg = { width: 3, r: 226, g: 75, b: 74, op: 1, dash: '10 6' };

  // Flip a connector from the gradient-stroked decoding stream to a flat
  // solid-red line. Called when the decode resolves (render_decode) or errors.
  function flattenConnectorStroke(id) {
    const g = document.querySelector(`.lens-connector-group[data-decode-id="${id}"]`);
    if (!g) return;
    const linePath = g.querySelector('.lens-connector-line');
    if (!linePath) return;
    linePath.setAttribute('stroke', `rgb(${connCfg.r}, ${connCfg.g}, ${connCfg.b})`);
  }

  function updateConnector(id) {
    const data = decodeById.get(id);
    if (!data) return;

    const g = document.querySelector(`.lens-connector-group[data-decode-id="${id}"]`);
    if (!g) return;
    const linePath = g.querySelector('.lens-connector-line');
    const shadowPath = g.querySelector('.lens-connector-shadow');
    if (!linePath) return;

    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    const cardRect = data.card.getBoundingClientRect();

    // END = middle of the section's primary content (image center / heading center)
    const anchor = findContentAnchor(data.element);
    const ex = anchor.x;
    const ey = anchor.y;

    // START = the card edge nearest the anchor
    const sy = cardRect.top + scrollY + cardRect.height / 2;
    let sx;
    if (ex > cardRect.right + scrollX) {
      sx = cardRect.right + scrollX;        // anchor is to the right of card
    } else if (ex < cardRect.left + scrollX) {
      sx = cardRect.left + scrollX;          // anchor is to the left of card
    } else {
      sx = cardRect.left + scrollX + cardRect.width / 2;
    }

    // Cubic bezier with horizontal control handles (smooth S-curve)
    const midX = (sx + ex) / 2;
    const d = `M ${sx} ${sy} C ${midX} ${sy}, ${midX} ${ey}, ${ex} ${ey}`;

    // Main line + shadow share the same path
    linePath.setAttribute('d', d);
    if (shadowPath) {
      shadowPath.setAttribute('d', d);
      shadowPath.setAttribute('stroke-width', String(connCfg.width + 3));
    }
    linePath.setAttribute('stroke-width', String(connCfg.width));
    // Stroke-dasharray is now controlled by CSS (state-aware: short pulse for
    // .decoding, longer slow pulse for the post-gen state). Don't override it
    // here or the CSS animation timing breaks.

    // Update the per-connector gradient to follow path direction so the dark→
    // bright color ramp goes card→tip regardless of where the card sits.
    const grad = document.getElementById(`lens-conn-grad-${id}`);
    if (grad) {
      grad.setAttribute('x1', sx); grad.setAttribute('y1', sy);
      grad.setAttribute('x2', ex); grad.setAttribute('y2', ey);
      // Derive dark/bright endpoints from connCfg color so design-panel sliders
      // still affect the gradient. Dark = 35% of base; bright = base + headroom.
      const r = connCfg.r, g_ = connCfg.g, b = connCfg.b;
      const dark = `rgb(${Math.floor(r * 0.35)}, ${Math.floor(g_ * 0.35)}, ${Math.floor(b * 0.35)})`;
      const bright = `rgb(${Math.min(255, r + 30)}, ${Math.min(255, g_ + 50)}, ${Math.min(255, b + 50)})`;
      const stops = grad.querySelectorAll('stop');
      if (stops[0]) stops[0].setAttribute('stop-color', dark);
      if (stops[1]) stops[1].setAttribute('stop-color', bright);
    }
  }

  // ============================================================
  // GLOBAL MOUSE HANDLERS (hover + drag)
  // ============================================================

  const onMouseMove = (e) => {
    if (dragState) {
      const dx = e.clientX - dragState.startX;
      const dy = e.clientY - dragState.startY;
      dragState.card.style.left = (dragState.origLeft + dx) + 'px';
      dragState.card.style.top = (dragState.origTop + dy) + 'px';
      updateConnector(dragState.id);
    } else {
      handleHover(e);
    }
  };

  const onMouseUp = () => {
    if (dragState) {
      dragState.card.classList.remove('dragging');
      document.body.style.userSelect = '';
      dragState = null;
    }
  };

  document.addEventListener('mousemove', onMouseMove);
  document.addEventListener('mouseup', onMouseUp);

  // Store cleanup for re-injection after extension reload
  window.__lensCleanup = () => {
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
    selectionEnabled = false;
  };

  // ============================================================
  // MESSAGE HANDLING
  // ============================================================

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'enable_selection') {
      injectStyles();
      selectionEnabled = true;
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'disable_selection') {
      selectionEnabled = false;
      clearHover();
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'render_decode') {
      const d = message.decode || {};
      updateCardContent(message.decodeId, message.label, d.pattern_name, d.absolution);
      sendResponse({ success: true });
      return true;
    }

    // Live status update during a multi-stage decode (article fetch → API call).
    // Replaces the body label so the user sees what's happening.
    if (message.type === 'decode_status') {
      const data = decodeById.get(message.decodeId);
      if (data) {
        const lbl = data.card.querySelector('.lens-card-label');
        if (lbl) lbl.textContent = message.status || 'Working…';
      }
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'decode_error') {
      showCardError(message.decodeId, message.error);
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'scroll_to_decode') {
      const data = decodeById.get(message.decodeId);
      if (data) data.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'update_design') {
      const d = message;
      // Card width is the only card geometry live-tunable now; everything else
      // is locked to the v0.4 visual spec and not exposed to the design panel.
      document.querySelectorAll('.lens-decode-card').forEach(el => { el.style.width = d.cardWidth + 'px'; });
      // Hover outline (live-tunable)
      const styleEl = document.getElementById('lens-styles-dynamic') || (() => {
        const s = document.createElement('style');
        s.id = 'lens-styles-dynamic';
        document.head.appendChild(s);
        return s;
      })();
      styleEl.textContent = `
        .lens-hover-outline {
          outline: ${d.hovW}px ${d.hovDash ? 'dashed' : 'solid'} rgba(${d.hovR},${d.hovG},${d.hovB},${d.hovOp}) !important;
          outline-offset: ${d.hovOff}px;
        }
      `;
      // Update arrow marker SIZE only — preserve the static 3D gradient fill +
      // dark outline. The arrow's color is part of the v0.4.18 visual identity
      // (light red top, dark red bottom, hairline outline) and shouldn't be
      // overwritten by the legacy color sliders. Use line dashes / line color
      // for tonal customization instead.
      const marker = document.getElementById('lens-arrow');
      if (marker) {
        marker.setAttribute('markerWidth', d.arrSize);
        marker.setAttribute('markerHeight', d.arrSize);
      }
      // Update connector config
      connCfg.width = d.arrWidth;
      connCfg.r = d.arrR; connCfg.g = d.arrG; connCfg.b = d.arrB;
      connCfg.op = d.arrOp;
      connCfg.dash = d.arrDash > 0 ? `${d.arrDash} ${Math.max(1, Math.round(d.arrDash * 0.75))}` : 'none';
      for (const [id] of decodeById) { updateConnector(id); }
      // Update section detection config
      if (d.secMinH !== undefined) {
        secConfig.minH = d.secMinH;
        secConfig.maxH = d.secMaxH;
        secConfig.minText = d.secMinText;
        secConfig.walkUp = d.secWalkUp;
        secConfig.skipH = !!d.secSkipH;
        secConfig.skipI = !!d.secSkipI;
        secConfig.skipP = !!d.secSkipP;
        clearSectionCache();
      }
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'toggle_overlays') {
      overlaysVisible = message.visible;
      document.querySelectorAll('.lens-decode-card').forEach(el => {
        el.style.display = overlaysVisible ? '' : 'none';
      });
      document.querySelectorAll('.lens-exhibit-tag').forEach(el => {
        el.style.display = overlaysVisible ? '' : 'none';
      });
      const svg = document.getElementById('lens-svg-layer');
      if (svg) svg.style.display = overlaysVisible ? '' : 'none';
      if (decodeBtn) decodeBtn.style.display = 'none';
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'remove_all_decodes') {
      const ids = [...decodeById.keys()];
      ids.forEach(id => removeDecode(id));
      sendResponse({ success: true });
      return true;
    }

    // Dev: regenerate the most recent decode with whatever dev params are
    // currently live. Removes the floating card + tag + connector AND asks
    // the sidepanel to remove its matching breakdown card, then retriggers
    // the same section so the new params take effect.
    //
    // Optional message.count (integer, default 1) fires N sequential
    // regenerations on the same section — each produces its own new floating
    // card + breakdown entry, so the dev can compare variance at current params.
    if (message.type === 'regenerate_last_decode') {
      const ids = [...decodeById.keys()];
      if (ids.length === 0) { sendResponse({ success: false, error: 'no decodes yet' }); return true; }
      const lastId = Math.max(...ids);
      const data = decodeById.get(lastId);
      if (!data) { sendResponse({ success: false, error: 'last decode missing' }); return true; }
      const section = data.element;
      // Tear down just the most recent one.
      data.card.remove();
      if (data.tagEl) data.tagEl.remove();
      section.classList.remove('lens-decoded-section');
      delete section.dataset.lensEx;
      decodes.delete(section);
      decodeById.delete(lastId);
      const connGroup = document.querySelector(`.lens-connector-group[data-decode-id="${lastId}"]`);
      if (connGroup) connGroup.remove();
      const oldGrad = document.getElementById(`lens-conn-grad-${lastId}`);
      if (oldGrad) oldGrad.remove();
      chrome.runtime.sendMessage({ type: 'decode_removed', decodeId: lastId, forRegenerate: true }).catch(() => {});

      // Fire N sequential triggers. Stagger so we don't slam OpenRouter with
      // simultaneous identical requests + give each a chance to be acked.
      const count = Math.max(1, Math.min(Number(message.count) || 1, 5));
      for (let i = 0; i < count; i++) {
        setTimeout(() => triggerDecode(section), 60 + i * 250);
      }
      sendResponse({ success: true });
      return true;
    }
  });
})();
