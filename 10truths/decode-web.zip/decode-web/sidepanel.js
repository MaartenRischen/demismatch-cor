// Side panel — injects content script, shows list of decoded sections

// DOM refs
const statusEl = document.getElementById('status');
const idleState = document.getElementById('idle-state');
const toggleBtn = document.getElementById('toggle-btn');
const exportBtn = document.getElementById('export-btn');
const cardsContainer = document.getElementById('cards-container');

// State
let pinnedTabId = null;
let pinnedTabUrl = '';
let overlaysVisible = true;
const decodedData = new Map();

// --- Cor reference map ---
const COR_ATLAS = 'https://cor.demismatch.com/atlas.html';
const COR_REF = {
  M1:  'Threat Management',
  M2:  'Pursuit / Exploration',
  M3:  'Social Bonding',
  M4:  'Social Calibration / Play',
  M5:  'Status Monitoring',
  M6:  'Controllability / Agency',
  M7:  'Circadian Regulation',
  M8:  'Immune Regulation',
  M9:  'Care / Alloparenting',
  M10: 'Movement / Regulatory',
  M11: 'Cooperation / Alliance',
  M12: 'Contamination Avoidance',
  M13: 'Energy Regulation',
  M14: 'Reproductive Motivation',
  R1:  'Touch',
  DA1: 'Defensive Signals Under Mismatch',
  DA2: 'Socially Scaffolded Regulation',
  DA3: 'Recurrent Coupling & Cascading',
  DA4: 'Proxy Hijacking via Open Loops',
  DA5: 'Defensive Over-Activation Bias',
  DA6: 'Competing Motivational Programs',
  DA7: 'Developmental Calibration',
  DA8: 'Phylogenetic Priority',
  DA9: 'Non-Substitutability',
  DC1: 'Allostatic Load Accumulation',
  DC2: 'Market Proxy Exploitation',
  DC3: 'Environment as Intervention Layer',
  C1:  'Inclusive Fitness as Loss Function',
  C2:  'Domain-Sensitive Architecture',
  C3:  'Systematic EEA-Modern Mismatch',
  C4:  'Phylogenetic Conservation',
  C5:  'Socially Scaffolded Regulation',
  C6:  'Wanting-Liking Dissociation',
  C7:  'Adverse Experience Cascading',
  C8:  'Error Management Asymmetry',
  C9:  'Allostatic Load Accumulation',
  C10: 'Threat-Detection Subcortical Circuits',
  C11: 'Reciprocity & Norm Enforcement',
  C12: 'Developmental Calibration',
  C13: 'Aversive Outputs as Defensive Signals',
  C14: 'Reproductive Motivation as Distinct Architecture',
};

function corSection(code) {
  if (code.startsWith('M') || code === 'R1') return 'mechanisms';
  if (code.startsWith('DA') || code.startsWith('DC') || code.startsWith('P') || code.startsWith('OF')) return 'foundations';
  if (code.startsWith('C')) return 'convergences';
  return 'mechanisms';
}


// --- Init ---

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { statusEl.textContent = 'No active tab'; return; }

  pinnedTabId = tab.id;
  pinnedTabUrl = tab.url || '';
  statusEl.textContent = 'Enabling...';

  const result = await chrome.runtime.sendMessage({ type: 'inject_and_enable', tabId: pinnedTabId });
  if (result?.error) { statusEl.textContent = 'Error: ' + result.error; return; }

  statusEl.textContent = '';
  toggleBtn.classList.remove('hidden');
  toggleBtn.classList.add('active');
}

init();

// --- Listen for decode results ---

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'decode_completed') {
    const { decodeId, exhibitNum, label, decode, headlines } = message;
    decodedData.set(decodeId, { exhibitNum, label, decode, headlines });
    addDecodeCard(decodeId, exhibitNum, label, decode, headlines);
    updateUI();
  }
  if (message.type === 'decode_error') {
    statusEl.textContent = 'Error: ' + message.error;
    setTimeout(() => updateUI(), 3000);
  }
  if (message.type === 'decode_removed') {
    // Default behavior: floating card removed, breakdown stays (log). When
    // `forRegenerate` is set, also purge the breakdown so the re-decode produces
    // a clean new entry.
    if (message.forRegenerate) {
      decodedData.delete(message.decodeId);
      const card = cardsContainer.querySelector(`.decode-card[data-decode-id="${message.decodeId}"]`);
      if (card) card.remove();
      updateUI();
    }
  }
  if (message.type === 'open_breakdown_in_panel' || message.type === 'open_breakdown') {
    const card = cardsContainer.querySelector(`.decode-card[data-decode-id="${message.decodeId}"]`);
    if (card) {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      card.classList.add('decode-card--highlighted');
      setTimeout(() => card.classList.remove('decode-card--highlighted'), 1500);
    }
  }
});

function updateUI() {
  const count = decodedData.size;
  idleState.classList.toggle('hidden', count > 0);
  statusEl.textContent = count > 0 ? `${count} decoded` : '';
  exportBtn.classList.toggle('hidden', count === 0);
}

// Drop every decode entry from the sidebar. Does NOT touch dev params or design
// sliders. Used on page refresh / navigation and by the Reset All button.
function clearSidebarDecodes() {
  decodedData.clear();
  if (cardsContainer) cardsContainer.innerHTML = '';
  updateUI();
}

// When the pinned tab reloads (refresh, navigation), the content script is torn
// down with the old page. The decoded DOM is gone, so the sidebar entries point
// to nothing. Clear them on 'loading', re-inject + re-enable on 'complete'.
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId !== pinnedTabId) return;
  if (changeInfo.status === 'loading') {
    clearSidebarDecodes();
    if (tab?.url) pinnedTabUrl = tab.url;
  } else if (changeInfo.status === 'complete') {
    // Re-inject so Lens keeps working after refresh without requiring the user
    // to re-activate via the extension icon.
    chrome.runtime.sendMessage({ type: 'inject_and_enable', tabId: pinnedTabId }).catch(() => {});
  }
});

// Helper: create a dom element with class and optional text.
function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

// Pattern names arrive from the LLM in all caps ("A FIGHT YOU CAN'T FIGHT").
// The hero block renders them in sentence case — capital first letter only.
function sentenceCasePattern(s) {
  if (!s) return '';
  const lower = String(s).toLowerCase();
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

function addDecodeCard(decodeId, exhibitNum, label, decode, headlines) {
  idleState.classList.add('hidden');
  const card = el('div', 'decode-card');
  card.dataset.decodeId = decodeId;

  const snap = (window.COR_SNAPSHOT || { mechanisms: {}, foundations: {} });

  // ── 1. Exhibit number eyebrow (small mono amber, own line) ──
  card.appendChild(el('div', 'bd-exhibit', `EX·${exhibitNum}`));

  // ── 2. Hero pattern name — big red serif, sentence case, full width ──
  card.appendChild(el('div', 'bd-hero', sentenceCasePattern(decode.pattern_name)));

  // ── 3. Stamped classification (oxblood, mechanism code is dynamic) ──
  const primaryCodeForStamp = (decode.mechanisms && decode.mechanisms[0]) || 'Primary';
  card.appendChild(el('div', 'bd-stamp', `${primaryCodeForStamp} engaged · Resolution blocked`));

  // ── 3. Primary mechanism ──
  const primaryCode = (decode.mechanisms && decode.mechanisms[0]) || null;
  const primaryInfo = primaryCode ? snap.mechanisms[primaryCode] : null;
  if (primaryCode) {
    const block = el('div', 'bd-primary');
    block.appendChild(el('div', 'bd-eyebrow', 'Primary mechanism'));
    const row = el('div', 'bd-primary-row');
    row.appendChild(el('span', 'bd-primary-code', primaryCode));
    row.appendChild(el('span', 'bd-primary-name', primaryInfo?.name || COR_REF[primaryCode] || primaryCode));
    block.appendChild(row);
    if (primaryInfo?.resolution) {
      const resLine = el('div', 'bd-primary-line');
      const resLbl = el('strong', null, 'Resolution condition: ');
      resLine.appendChild(resLbl);
      resLine.appendChild(document.createTextNode(primaryInfo.resolution));
      block.appendChild(resLine);
    }
    const metLine = el('div', 'bd-primary-line');
    const metLbl = el('strong', null, 'Met by reader action: ');
    metLine.appendChild(metLbl);
    metLine.appendChild(el('span', 'bd-primary-no', 'NO'));
    block.appendChild(metLine);
    card.appendChild(block);
  }

  // ── 4. Cascade (hidden if primary has no suppressed list) ──
  const cascade = primaryInfo?.cascade_suppresses || [];
  if (cascade.length) {
    const block = el('div', 'bd-cascade');
    block.appendChild(el('div', 'bd-eyebrow', `Cascade · ${primaryCode} suppresses`));
    const list = el('div', 'bd-cascade-list');
    cascade.forEach(code => {
      const info = snap.mechanisms[code];
      const row = el('div', 'bd-cascade-row');
      row.appendChild(el('span', 'bd-cascade-code', code));
      row.appendChild(el('span', 'bd-cascade-name', info?.name || COR_REF[code] || code));
      row.appendChild(el('span', 'bd-cascade-glyph', '↓'));
      list.appendChild(row);
    });
    block.appendChild(list);
    card.appendChild(block);
  }

  // ── 5. Foundations (from decode.properties array) ──
  const properties = decode.properties || [];
  if (properties.length) {
    const block = el('div', 'bd-foundations');
    block.appendChild(el('div', 'bd-eyebrow', 'Foundations'));
    const list = el('div', 'bd-foundation-list');
    properties.forEach(code => {
      const name = snap.foundations[code] || COR_REF[code] || code;
      const row = el('div', 'bd-foundation-row');
      row.appendChild(el('span', 'bd-foundation-code', code));
      row.appendChild(el('span', 'bd-foundation-name', name));
      list.appendChild(row);
    });
    block.appendChild(list);
    card.appendChild(block);
  }

  // ── 6. Evidence chain — three § rows from the three existing fields ──
  const evidenceItems = [
    decode.whats_happening,
    decode.the_mismatch,
    decode.for_you
  ].filter(Boolean);
  if (evidenceItems.length) {
    const block = el('div', 'bd-evidence');
    block.appendChild(el('div', 'bd-eyebrow', 'Evidence chain'));
    evidenceItems.forEach((text, i) => {
      const row = el('div', 'bd-evidence-row');
      row.appendChild(el('span', 'bd-evidence-num', `§ ${String(i + 1).padStart(2, '0')}`));
      row.appendChild(el('p', 'bd-evidence-text', text));
      block.appendChild(row);
    });
    card.appendChild(block);
  }

  // ── 7. References (existing deep-link chips, relabeled) ──
  addCorRefs(card, decode);

  // Click the card → scroll the page to the decoded section (existing behavior)
  card.addEventListener('click', () => {
    if (pinnedTabId) {
      chrome.tabs.sendMessage(pinnedTabId, { type: 'scroll_to_decode', decodeId }).catch(() => {});
    }
  });

  cardsContainer.appendChild(card);
}

function addCorRefs(card, decode) {
  const refs = [];
  if (decode.mechanisms?.length) decode.mechanisms.forEach(c => refs.push({ code: c }));
  if (decode.properties?.length) decode.properties.forEach(c => refs.push({ code: c }));
  if (decode.convergences?.length) decode.convergences.forEach(c => refs.push({ code: c }));
  if (refs.length === 0) return;

  const snap = (window.COR_SNAPSHOT || { mechanisms: {}, foundations: {} });
  const refsEl = el('div', 'card-cor-refs');
  refsEl.appendChild(el('div', 'bd-eyebrow', 'References'));
  const tagContainer = el('div', 'cor-ref-tags');

  refs.forEach(({ code }) => {
    const name = snap.mechanisms[code]?.name
      || snap.foundations[code]
      || COR_REF[code];
    if (!name) return;
    const tag = document.createElement('a');
    tag.className = 'cor-ref-tag';
    tag.href = `${COR_ATLAS}#${corSection(code)}`;
    tag.target = '_blank';
    tag.rel = 'noopener';
    tag.innerHTML = `<span class="cor-ref-code">${code}</span>${name}`;
    tag.addEventListener('click', (e) => e.stopPropagation());
    tagContainer.appendChild(tag);
  });

  refsEl.appendChild(tagContainer);
  card.appendChild(refsEl);
}

// --- Design controls ---

const designBtn = document.getElementById('design-btn');
const designControls = document.getElementById('design-controls');

designBtn.addEventListener('click', () => {
  designBtn.classList.toggle('active');
  designControls.classList.toggle('hidden');
});

// Collect all slider values into a flat object
function collectValues() {
  const vals = {};
  designControls.querySelectorAll('input[type="range"]').forEach(input => {
    vals[input.id] = Number(input.value);
  });
  return vals;
}

// Apply values from object to sliders
function applyValues(vals) {
  for (const [id, val] of Object.entries(vals)) {
    const input = document.getElementById(id);
    if (input) {
      input.value = val;
      const valEl = document.getElementById('v-' + id.slice(2));
      if (valEl) valEl.textContent = val;
    }
  }
  sendDesign();
}

// Export values as JSON
document.getElementById('dc-export-vals').addEventListener('click', () => {
  const vals = collectValues();
  const blob = new Blob([JSON.stringify(vals, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({
    url,
    filename: `lens-design-values.json`,
    saveAs: true
  }, () => URL.revokeObjectURL(url));
});

// Import values from JSON
document.getElementById('dc-import-vals').addEventListener('click', () => {
  document.getElementById('dc-import-file').click();
});

document.getElementById('dc-import-file').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const vals = JSON.parse(reader.result);
      applyValues(vals);
    } catch { statusEl.textContent = 'Invalid JSON'; }
  };
  reader.readAsText(file);
  e.target.value = '';
});

function sendDesign() {
  const g = id => parseFloat(document.getElementById(id)?.value || 0);

  // Update value displays
  designControls.querySelectorAll('input[type="range"]').forEach(input => {
    const valEl = document.getElementById('v-' + input.id.slice(2));
    if (valEl) valEl.textContent = input.value;
  });

  if (!pinnedTabId) return;

  chrome.tabs.sendMessage(pinnedTabId, {
    type: 'update_design',
    // Card BG
    cardWidth: g('c-card-w'),
    cardBgR: g('c-card-bgr'), cardBgG: g('c-card-bgg'), cardBgB: g('c-card-bgb'),
    cardBgOp: g('c-card-bgop') / 100,
    cardBBlur: g('c-card-bblur'), cardBSat: g('c-card-bsat') / 100,
    // Card border
    cardBLW: g('c-card-blw'),
    cardBLR: g('c-card-blr'), cardBLG: g('c-card-blg'), cardBLB: g('c-card-blb'),
    cardBLO: g('c-card-blo') / 100,
    cardBEW: g('c-card-bew'),
    cardBER: g('c-card-ber'), cardBEG: g('c-card-beg'), cardBEB: g('c-card-beb'),
    cardBEO: g('c-card-beo') / 100,
    cardRadius: g('c-card-rad'),
    // Card spacing/shadow
    cardPadH: g('c-card-ph'), cardPadV: g('c-card-pv'),
    cardS1Y: g('c-card-s1y'), cardS1B: g('c-card-s1b'), cardS1S: g('c-card-s1s'), cardS1O: g('c-card-s1o') / 100,
    cardS2Y: g('c-card-s2y'), cardS2B: g('c-card-s2b'), cardS2O: g('c-card-s2o') / 100,
    cardInset: g('c-card-inset') / 100,
    cardHLift: g('c-card-hlift'), cardDScale: g('c-card-dscale') / 100,
    // Label text
    txtSize: g('c-txt-size'), txtWeight: g('c-txt-weight'),
    txtLh: g('c-txt-lh') / 100, txtLs: g('c-txt-ls') / 10, txtWs: g('c-txt-ws') / 10,
    txtUpper: g('c-txt-upper'),
    txtR: g('c-txt-r'), txtG: g('c-txt-g'), txtB: g('c-txt-b'), txtOp: g('c-txt-op') / 100,
    txtShX: g('c-txt-shx'), txtShY: g('c-txt-shy'), txtShBlur: g('c-txt-shblur'), txtShDark: g('c-txt-shdark') / 100,
    // Close button
    clsSize: g('c-cls-size'), clsRad: g('c-cls-rad'), clsIcon: g('c-cls-icon'),
    clsBgOp: g('c-cls-bgop') / 100, clsIOp: g('c-cls-iop') / 100,
    clsHBg: g('c-cls-hbg') / 100, clsHIOp: g('c-cls-hiop') / 100,
    // Connector
    arrWidth: g('c-arr-w'),
    arrR: g('c-arr-r'), arrG: g('c-arr-g'), arrB: g('c-arr-b'),
    arrOp: g('c-arr-op') / 100, arrDash: g('c-arr-dash'),
    arrSize: g('c-arr-size'), arrFillOp: g('c-arr-fillop') / 100,
    // Outline decoded
    outWidth: g('c-out-w'),
    outR: g('c-out-r'), outG: g('c-out-g'), outB: g('c-out-b'),
    outOp: g('c-out-op') / 100, outOff: g('c-out-off'),
    // Outline hover
    hovW: g('c-hov-w'),
    hovR: g('c-hov-r'), hovG: g('c-hov-g'), hovB: g('c-hov-b'),
    hovOp: g('c-hov-op') / 100, hovDash: g('c-hov-dash'), hovOff: g('c-hov-off'),
    // Decode button
    btnBgR: g('c-btn-bgr'), btnBgG: g('c-btn-bgg'), btnBgB: g('c-btn-bgb'),
    btnBgOp: g('c-btn-bgop') / 100, btnBlur: g('c-btn-blur'),
    btnRad: g('c-btn-rad'), btnFs: g('c-btn-fs'), btnFw: g('c-btn-fw'),
    btnPh: g('c-btn-ph'), btnPv: g('c-btn-pv'), btnLs: g('c-btn-ls') / 10,
    btnHScale: g('c-btn-hscale') / 100,
    // Section detection
    secMinH: g('c-sec-minh'), secMaxH: g('c-sec-maxh') / 100,
    secMinText: g('c-sec-mint'), secWalkUp: g('c-sec-walkup'),
    secSkipH: g('c-sec-skiph'), secSkipI: g('c-sec-skipi'), secSkipP: g('c-sec-skipp'),
  }).catch(() => {});
}

designControls.querySelectorAll('input[type="range"]').forEach(input => {
  input.addEventListener('input', sendDesign);
});

// --- Dev decode parameters (granular dials for experimenting with decode output) ---

const DP_LABELS = {
  humor:     ['off', 'light', 'moderate', 'heavy', 'max'],
  tone:      ['clinical', 'deadpan+humor', 'compassionate', 'punchy', 'academic'],
  formality: ['default', 'very casual', 'casual', 'formal', 'very formal'],
  warmth:    ['default', 'ice cold', 'cool', 'warm', 'intimate'],
  direct:    ['default', 'circumspect', 'measured', 'blunt', 'confrontational'],
  sentl:     ['default', 'staccato', 'short', 'standard', 'flowing'],
  meta:      ['default', 'none', 'light', 'rich', 'dense'],
  pform:     ['auto', 'relationship', 'inability', 'field-note'],
  pcase:     ['auto', 'FORCE UPPER', 'force sentence'],
  absl:      ['off', 'on'],
  verb:      ['terse', 'standard', 'verbose'],
  layer:     ['off', 'on'],
  casc:      ['none', 'primary only', 'primary + one', 'full'],
  dc2:       ['suppress', 'default', 'emphasize', 'hammer'],
  scale:     ['suppress', 'default', 'emphasize', 'hammer'],
  schd:      ['suppress', 'auto', 'emphasize'],
  eea:       ['loose', 'default', 'strict', 'max']
};

// Source-of-truth defaults. Reset button restores these.
// Hardcoded baseline: opus-4-6 + temp 1.0 + max tokens 2624 + max humor +
// deadpan+humor + very casual + ice cold + confrontational + no metaphor.
// Other groups stay at framework defaults; tweak via dials and use Export
// Values to capture new presets.
const DP_DEFAULTS = {
  model: 'anthropic/claude-opus-4-6', temp: 10, topp: 100, freqp: 0, presp: 0, maxt: 2624, seed: '',
  humor: 4, tone: 1, formality: 1, warmth: 1, direct: 4, sentl: 0, meta: 1,
  pform: 0, pwords: 6, pcase: 0, lwords: 60, absl: 1, awords: 40, verb: 1,
  layer: 1, casc: 1, dc2: 1, scale: 1, schd: 1, eea: 1,
  custom: ''
};

const DP_IDS = Object.keys(DP_DEFAULTS);

function getDpEl(key) { return document.getElementById('c-dp-' + key); }
function getDpValEl(key) { return document.getElementById('v-dp-' + key); }

function readDpRaw() {
  const out = {};
  for (const k of DP_IDS) {
    const el = getDpEl(k);
    if (!el) continue;
    if (el.tagName === 'TEXTAREA') out[k] = el.value || '';
    else if (el.tagName === 'SELECT') out[k] = el.value;
    else if (el.type === 'number') out[k] = el.value === '' ? '' : Number(el.value);
    else out[k] = Number(el.value);
  }
  return out;
}

function dpToParams(raw) {
  return {
    model: raw.model,
    temperature: raw.temp / 10,
    topP: raw.topp / 100,
    frequencyPenalty: raw.freqp / 10,
    presencePenalty: raw.presp / 10,
    maxTokens: raw.maxt,
    seed: raw.seed === '' ? null : Number(raw.seed),
    humor: raw.humor,
    tone: raw.tone,
    formality: raw.formality,
    warmth: raw.warmth,
    direct: raw.direct,
    sentenceLen: raw.sentl,
    metaphor: raw.meta,
    patternForm: raw.pform,
    patternMaxWords: raw.pwords,
    patternCase: raw.pcase,
    labelWords: raw.lwords,
    absolutionOn: raw.absl === 1,
    absolutionWords: raw.awords,
    verbosity: raw.verb,
    multiLayer: raw.layer === 1,
    cascadeDepth: raw.casc,
    dc2Emphasis: raw.dc2,
    scaleEmphasis: raw.scale,
    schadenfreude: raw.schd,
    eeaStrictness: raw.eea,
    custom: raw.custom
  };
}

function refreshDpLabels(raw) {
  const set = (id, v) => { const el = getDpValEl(id); if (el) el.textContent = v; };
  set('model', raw.model.replace(/^.+\//, ''));
  set('temp', (raw.temp / 10).toFixed(1));
  set('topp', (raw.topp / 100).toFixed(2));
  set('freqp', (raw.freqp / 10).toFixed(1));
  set('presp', (raw.presp / 10).toFixed(1));
  set('maxt', raw.maxt);
  set('humor', DP_LABELS.humor[raw.humor]);
  set('tone', DP_LABELS.tone[raw.tone]);
  set('formality', DP_LABELS.formality[raw.formality]);
  set('warmth', DP_LABELS.warmth[raw.warmth]);
  set('direct', DP_LABELS.direct[raw.direct]);
  set('sentl', DP_LABELS.sentl[raw.sentl]);
  set('meta', DP_LABELS.meta[raw.meta]);
  set('pform', DP_LABELS.pform[raw.pform]);
  set('pwords', raw.pwords);
  set('pcase', DP_LABELS.pcase[raw.pcase]);
  set('lwords', raw.lwords);
  set('absl', DP_LABELS.absl[raw.absl]);
  set('awords', raw.awords);
  set('verb', DP_LABELS.verb[raw.verb]);
  set('layer', DP_LABELS.layer[raw.layer]);
  set('casc', DP_LABELS.casc[raw.casc]);
  set('dc2', DP_LABELS.dc2[raw.dc2]);
  set('scale', DP_LABELS.scale[raw.scale]);
  set('schd', DP_LABELS.schd[raw.schd]);
  set('eea', DP_LABELS.eea[raw.eea]);
}

function sendDecodeParams() {
  const raw = readDpRaw();
  refreshDpLabels(raw);
  chrome.runtime.sendMessage({ type: 'set_decode_params', params: dpToParams(raw) }).catch(() => {});
}

function applyDpDefaults() {
  for (const [k, v] of Object.entries(DP_DEFAULTS)) {
    const el = getDpEl(k);
    if (!el) continue;
    if (el.tagName === 'TEXTAREA' || el.type === 'number' || el.tagName === 'SELECT') el.value = v;
    else el.value = v;
  }
  sendDecodeParams();
}

// Wire all dials
for (const k of DP_IDS) {
  const el = getDpEl(k);
  if (!el) continue;
  const evt = (el.tagName === 'TEXTAREA' || el.type === 'number') ? 'change' : 'input';
  el.addEventListener(evt, sendDecodeParams);
  if (el.tagName === 'SELECT') el.addEventListener('change', sendDecodeParams);
}

// Fire once on load so background has the initial state + labels sync
sendDecodeParams();

// Regenerate last decode — uses the content script to tear down the most recent
// decode and retrigger it under current dev params.
document.getElementById('dc-regenerate')?.addEventListener('click', () => {
  if (!pinnedTabId) return;
  chrome.tabs.sendMessage(pinnedTabId, { type: 'regenerate_last_decode' }).catch(() => {});
});

// ×3: regenerate three times in sequence. Lets the dev eyeball variance at
// current params. Each run produces its own breakdown card in the sidebar for
// side-by-side comparison.
document.getElementById('dc-regenerate-3')?.addEventListener('click', () => {
  if (!pinnedTabId) return;
  chrome.tabs.sendMessage(pinnedTabId, { type: 'regenerate_last_decode', count: 3 }).catch(() => {});
});

// Reset all dev params to defaults.
document.getElementById('dc-reset-params')?.addEventListener('click', () => {
  applyDpDefaults();
});

// Reset ALL — full wipe back to startup state:
//   1. Clear every decoded section on the page (tells content script to
//      remove floating cards + tags + connectors + decoded-section markers).
//   2. Clear the sidebar log.
//   3. Reset all dev dials to defaults.
//   4. Reset all design sliders / selects / textareas to their HTML defaults.
function resetAll() {
  // 1. Tell content script to remove all in-page decorations.
  if (pinnedTabId) {
    chrome.tabs.sendMessage(pinnedTabId, { type: 'remove_all_decodes' }).catch(() => {});
  }
  // 2. Drop sidebar entries.
  clearSidebarDecodes();
  // 3. Reset dev dials.
  applyDpDefaults();
  // 4. Reset every design-panel control to its HTML default value.
  designControls.querySelectorAll('input[type="range"]').forEach(input => {
    input.value = input.defaultValue;
  });
  designControls.querySelectorAll('input[type="number"]').forEach(input => {
    input.value = input.defaultValue;
  });
  designControls.querySelectorAll('textarea').forEach(t => {
    t.value = t.defaultValue;
  });
  designControls.querySelectorAll('select').forEach(sel => {
    const defIdx = [...sel.options].findIndex(o => o.defaultSelected);
    sel.selectedIndex = defIdx >= 0 ? defIdx : 0;
  });
  // Push updated values downstream so content script + background resync.
  sendDesign();
  sendDecodeParams();
  sendFetchSettings();
}

document.getElementById('dc-reset-all')?.addEventListener('click', resetAll);

// --- Article fetching settings ---

const FS_DEFAULTS = { on: 1, to: 8, hy: 1500, mw: 100, ar: 1 };

function readFetchSettings() {
  const g = id => Number(document.getElementById('c-fs-' + id)?.value ?? FS_DEFAULTS[id]);
  const raw = { on: g('on'), to: g('to'), hy: g('hy'), mw: g('mw'), ar: g('ar') };
  // Update labels
  const set = (id, v) => { const el = document.getElementById('v-fs-' + id); if (el) el.textContent = v; };
  set('on', raw.on === 1 ? 'on' : 'off');
  set('to', raw.to);
  set('hy', raw.hy);
  set('mw', raw.mw);
  set('ar', raw.ar === 1 ? 'on' : 'off');
  return {
    enabled: raw.on === 1,
    timeoutMs: raw.to * 1000,
    hydrationDelayMs: raw.hy,
    minWordCount: raw.mw,
    archiveFallback: raw.ar === 1
  };
}

function sendFetchSettings() {
  const s = readFetchSettings();
  chrome.runtime.sendMessage({ type: 'set_fetch_settings', settings: s }).catch(() => {});
}

['c-fs-on', 'c-fs-to', 'c-fs-hy', 'c-fs-mw', 'c-fs-ar'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('input', sendFetchSettings);
});

// Push initial state on load
sendFetchSettings();

document.getElementById('dc-clear-article-cache')?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'clear_article_cache' }, (resp) => {
    if (resp?.ok) {
      const oldStatus = statusEl.textContent;
      statusEl.textContent = `cache: ${resp.removed} cleared`;
      setTimeout(() => { statusEl.textContent = oldStatus; }, 1800);
    }
  });
});

// --- Toggle overlays ---

toggleBtn.addEventListener('click', () => {
  overlaysVisible = !overlaysVisible;
  toggleBtn.classList.toggle('active', overlaysVisible);
  if (pinnedTabId) {
    chrome.tabs.sendMessage(pinnedTabId, { type: 'toggle_overlays', visible: overlaysVisible }).catch(() => {});
  }
});

// --- Export decodes ---

exportBtn.addEventListener('click', () => {
  if (decodedData.size === 0) return;
  const now = new Date();
  const date = now.toISOString().slice(0, 16).replace('T', ' ');
  let hostname = 'unknown';
  try { hostname = new URL(pinnedTabUrl).hostname; } catch {}
  function wc(s) { return s ? s.split(/\s+/).filter(Boolean).length : 0; }

  let md = `# Decode Web — Decode Export\n**Page:** ${pinnedTabUrl}\n**Date:** ${date}\n\n---\n`;
  let i = 0;
  for (const [id, data] of decodedData) {
    i++;
    const hl = data.headlines.map(h => `- ${h}`).join('\n');
    const allCodes = [
      ...(data.decode.mechanisms || []),
      ...(data.decode.properties || []),
      ...(data.decode.convergences || [])
    ];
    const corRefsMd = allCodes.length
      ? '\n**Cor architecture:** ' + allCodes.map(c => `${c} (${COR_REF[c] || c})`).join(', ') + '\n'
      : '';
    md += `\n### Decode ${i}\n**Headlines:**\n${hl}\n\n**Label:** ${data.label}\n**What's happening** (${wc(data.decode.whats_happening)}w): ${data.decode.whats_happening}\n**The mismatch** (${wc(data.decode.the_mismatch)}w): ${data.decode.the_mismatch}\n**For you** (${wc(data.decode.for_you)}w): ${data.decode.for_you}${corRefsMd}\n\n---\n`;
  }

  const blob = new Blob([md], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const ts = now.toISOString().replace(/[:.]/g, '-').slice(0, 19);
  chrome.downloads.download({ url, filename: `lens-decode-${hostname}-${ts}.md`, saveAs: false }, () => URL.revokeObjectURL(url));
});
